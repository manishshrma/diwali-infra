# Moment Forever Infra (CD / GitOps Repo)

> **Start here (November 2026): we are moving from a paid AWS server to a free,
> cloud-neutral setup on Oracle Cloud.** Read in this order:
>
> 1. [doc/CLOUD-MOVE-DECISIONS.md](doc/CLOUD-MOVE-DECISIONS.md) — what we decided and why, in plain English
> 2. [doc/COST-BEFORE-AND-AFTER.md](doc/COST-BEFORE-AND-AFTER.md) — ₹6,000/month → ₹0, and where the saving comes from
> 3. [doc/SIZING-FOR-1M-REQUESTS-A-DAY.md](doc/SIZING-FOR-1M-REQUESTS-A-DAY.md) — whether the free server copes with 1M requests a day
> 4. [doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md](doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md) — step-by-step deployment for anyone
> 5. [doc/MIGRATION-CHECKLIST.md](doc/MIGRATION-CHECKLIST.md) — what is done, what is still to do by hand, and the questions still open
>
> The scripts in `bootstrap/k3s/` and the manifests in `clusters/dev/` match
> that guide. `doc/EC2-K3S-BOOTSTRAP-GUIDE.md` and `doc/CD-OPERATIONS-RUNBOOK.md`
> describe the **previous AWS setup** and are kept for background.

This folder is a **CD (Continuous Delivery) GitOps repository structure** for:

- platform
- booking
- payment
- gateway
- billing

It is intentionally separate from application code repositories.

---

## Why this repo exists

- App repos do **CI** (build, test, docker push).
- This infra repo does **CD intent** (Kubernetes desired state).
- Argo CD watches this repo and applies changes to cluster.
- Argo CD Image Updater updates image tags automatically to new commit SHA tags.
- **Secrets are not in this repo.** They live in `.env` on the server and are
  turned into Kubernetes Secrets by `bootstrap/k3s/55-create-app-secrets.sh`.

---

## Folder structure

```text
moment-forever-infra/
  bootstrap/k3s/              scripts: fresh Ubuntu server -> running environment (any cloud)
    env.example               every setting, explained; copy to .env on the server
    00-... 60-...             one script per step; bootstrap-all.sh runs them in order
  argocd/
    app-project.yaml          what Argo CD may touch
    root-application.yaml     "app of apps": creates the children below
    applications/             one Argo Application per folder under clusters/dev
  clusters/dev/
    ingress/                  https://api.dev.decevent.com -> gateway (+ rate limit)
    argocd/                   https://argocd.dev.decevent.com
    dashboard/                https://dashboard.dev.decevent.com (view-only login)
    shared-infra/             consul, redis, kafka, mongo (replica set rs0 + init job)
    platform-db/ booking-db/ payment-db/   one PostgreSQL each
    platform/ booking/ payment/ billing/ gateway/
                              configmap.yaml (settings, heap, log levels)
                              deployment.yaml (limits, probes, log folder)
                              service.yaml, kustomization.yaml (image tag)
  doc/                        the documents listed at the top
```

---

## Bootstrap (first-time setup)

On a fresh Ubuntu server with a public IP:

```bash
git clone https://github.com/ForeverMoment-Corp/moment-forever-infra.git
cd moment-forever-infra/bootstrap/k3s
cp env.example .env && nano .env
chmod +x ./*.sh && ./bootstrap-all.sh
```

The scripts install k3s, NGINX ingress, cert-manager, Argo CD and Image
Updater, create the Secrets from `.env`, and hand over to Argo CD, which
deploys everything under `clusters/dev/`. Full walkthrough:
[doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md](doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md);
short version: [bootstrap/k3s/README.md](bootstrap/k3s/README.md).

---

## How image updates happen

- CI pushes a multi-arch image `groote123/<service>:<commit-sha>` (ARM + Intel).
- Image Updater (on the server) sees the new tag and writes it into
  `clusters/dev/<service>/kustomization.yaml` in this repo.
- Argo CD applies the change; Kubernetes starts the new version and stops the
  old one once the new one is healthy.

Push to `main` is the deployment. Typical time: 10–15 minutes.

---

## Public addresses

- API: `https://api.dev.decevent.com`
- Argo CD UI: `https://argocd.dev.decevent.com`
- Kubernetes Dashboard: `https://dashboard.dev.decevent.com` — **view-only**
  login: `kubectl -n kubernetes-dashboard create token viewer` (full admin for
  a one-off task: `clusters/dev/dashboard/README.md`)

All three carry real Let's Encrypt certificates issued by cert-manager.

---

## Important notes

- No deployment commands are kept in application CI workflows.
- No `kubectl` from app repos.
- CD state changes happen in this infra repo only.
- Comments in every YAML are intentionally verbose for learning.

---

## Extra beginner docs

- `doc/FILE-BY-FILE-EXPLANATION.md`
- `doc/ARGOCD-KUBERNETES-BASICS.md`
- `doc/LOCAL-CD-SETUP-GUIDE.md`
- `doc/DEVOPS-TERMINOLOGY-GLOSSARY.md`
- `doc/KUBERNETES-ARGOCD-DEEP-DIVE-RUNBOOK.md` (in-depth commands + debugging)
- `doc/CD-OPERATIONS-RUNBOOK.md` and `doc/EC2-K3S-BOOTSTRAP-GUIDE.md` (previous AWS setup; partly historical)
