# Migration checklist — from the AWS setup to the free cloud-neutral setup

This is the ordered list of work that turns the decisions in
[CLOUD-MOVE-DECISIONS.md](CLOUD-MOVE-DECISIONS.md) into reality.

**Status (7 November 2026): everything that lives in the repositories (sections
A–C) is done and waiting to be reviewed, committed and pushed.** What remains
is work in web consoles and decisions from the business (sections D–H).
[DEPLOYMENT-GUIDE-ANY-CLOUD.md](DEPLOYMENT-GUIDE-ANY-CLOUD.md) describes what
the scripts now do.

Tick a box only when the change is merged to `main` (A–C) or actually done (D–H).

Legend: **(infra)** = this repo · **(platform/booking/…)** = that service's repo
· **(console)** = done by hand in a web console · **(you)** = needs a decision
or a value from the business.

---

## A. Bootstrap scripts, cloud-neutral (infra) — done, to be committed

- [x] `bootstrap/ec2-k3s/` renamed to `bootstrap/k3s/`; doc links updated; the
      two AWS-era docs carry a "historical" banner.
- [x] `common.sh`: no more EC2 metadata lookup or `checkip.amazonaws.com`.
      `PUBLIC_IP`, `APP_HOST`, `ARGOCD_HOST`, `DASHBOARD_HOST` are **required**
      in `.env`; a DNS check warns when a name does not point at the server;
      git runs with `safe.directory` (needed on Ubuntu 24.04 where the repo is
      owned by `ubuntu` and the scripts run as root); the "is this checkout
      pushed?" check works for private repos by fetching with the PAT.
- [x] New `05-open-host-firewall.sh`: removes the blanket REJECT rules that
      Oracle's Ubuntu images ship (they block 80/443 *and* pod-to-node traffic,
      which breaks Argo CD); no-op on other clouds; persists across reboots.
- [x] `10-install-k3s.sh`: container log rotation (10 MB × 3 per container).
- [x] New `15-setup-log-cleanup.sh`: `/var/log/moment-forever/<service>`
      folders + a weekly systemd timer (Sunday 03:00) deleting log files older
      than `LOG_RETENTION_DAYS` (7), trimming the journal (300 MB cap) and
      pruning unused images.
- [x] `20-install-nginx-ingress.sh`: ingress access log off.
- [x] New `55-create-app-secrets.sh`: Kubernetes Secrets for postgres, gateway,
      platform, booking, payment, billing **from `.env`**; re-runnable;
      refuses to run without the five values nothing can start without.
- [x] `60-bootstrap-moment-forever.sh`: checks DNS and that the Secrets exist;
      waits for all twelve Argo applications incl. billing; prints the
      `https://` URLs and the Dashboard view-only token command.
- [x] `env.example`: every variable with a plain-English comment, grouped.
- [x] `bootstrap-all.sh`: runs 00, 05, 10, 15, 20, 25, 30, 40, 50, 55, 60.
- [x] `cluster-files-dump.txt` and `argocd/image-updater.yaml` deleted.

## B. Manifests (infra) — done, to be committed

- [x] Hostnames `api.dev.decevent.com`, `argocd.dev.decevent.com`,
      `dashboard.dev.decevent.com` in the three ingress files.
- [x] **Dashboard, view-only login** (`clusters/dev/dashboard/viewer.yaml`:
      `viewer` ServiceAccount bound to the built-in `view` role plus read-only
      nodes/metrics). The full-admin binding is now
      `optional-admin-user.yaml`, applied by hand for a one-off task and
      deleted afterwards (`clusters/dev/dashboard/README.md`). Memory limits
      added via kustomize patches.
- [x] **Three PostgreSQL servers stay** (D6): 512 MB limit, `shared_buffers=128MB`,
      password from the `postgres-secret` Secret, 5 GB volumes, readiness probes.
- [x] **One MongoDB as replica set** `rs0` (`mongo` StatefulSet + `mongo-init`
      Job); Service renamed `mongo-booking` → `mongo`; `MONGO_HOST: mongo` in
      the platform and booking ConfigMaps.
- [x] **Billing**: `clusters/dev/billing/` (ConfigMap with `MONGODB_URI`
      replica-set URI, Deployment on 8084 with `/billing/actuator/health`
      probes, Service, kustomization) and `argocd/applications/billing.yaml`.
- [x] Booking ConfigMap: `BILLING_INTERNAL_BASE_URL=http://billing/billing`;
      `BILLING_INTERNAL_TOKEN` in the booking and billing Secrets.
- [x] **Memory limits + fixed Java heap** on every Deployment/StatefulSet per
      [SIZING-FOR-1M-REQUESTS-A-DAY.md](SIZING-FOR-1M-REQUESTS-A-DAY.md) §2
      (`JAVA_TOOL_OPTIONS` with `-Xmx`, `-XX:+ExitOnOutOfMemoryError`,
      timezone). Kafka `KAFKA_HEAP_OPTS=-Xmx512m`, retention 7 days. Redis
      `--maxmemory 256mb --maxmemory-policy allkeys-lru`. Startup probes (up to
      5 minutes) so a slow JVM start on ARM is not mistaken for a crash.
- [x] **Traffic hardening**: log levels INFO through `-Dlogging.level.*` flags
      in each service's `JAVA_TOOL_OPTIONS` (the services' `logback.xml` files
      are DEBUG/TRACE for local development; this overrides them without a
      code change); `SPRING_JPA_SHOW_SQL=false`; ingress
      `limit-rps: "20"`; Platform `SPRING_DATASOURCE_HIKARI_MAXIMUM_POOL_SIZE=20`.
- [x] **Logs on disk**: every service Deployment mounts
      `/var/log/moment-forever/<service>` at `/app/logs` (where the services
      write their own log files), so the weekly cleanup from A can delete them.
- [x] Every `clusters/dev/*/secret.yaml` deleted; Razorpay keys removed from
      the payment ConfigMap; the AppProject comment says why Secrets are not
      in Git.
- [x] New settings: `CORS_ALLOWED_ORIGINS` (gateway ConfigMap, pre-filled with
      `https://www.decevent.com`), `RAZORPAY_CALLBACK_URL` (payment ConfigMap,
      placeholder — see F), the rest via `.env` → Secrets.
- [x] `imagePullPolicy: Always` on the five service Deployments.

## C. CI and images (service repos) — done, to be committed in each repo

- [x] **(platform)** `reusable-ci.yml`: Buildx + QEMU; pull requests build an
      Intel image only (fast check, no push); pushes publish one multi-arch
      image (`linux/amd64,linux/arm64`) tagged with the commit SHA and, on
      `main`, `latest`; GitHub Actions cache for layers.
- [x] **(all five)** Dockerfile: build stage pinned to `--platform=$BUILDPLATFORM`
      so Maven never runs under emulation; runtime stage `eclipse-temurin:17-jre`
      (multi-arch, Java runtime only, about half the size).
- [x] **(billing)** `.github/workflows/ci.yml` (+ the GitLab mirror workflow
      the other repos have) calling the shared workflow with
      `groote123/moment-forever-billing`.
- [x] **(gateway)** `application.yml`: CORS allow-list (`globalcors`) driven by
      `CORS_ALLOWED_ORIGINS`. Before this no service answered CORS at all.
- [ ] **(console)** Create the Docker Hub repository `groote123/moment-forever-billing`
      and add the `DOCKERHUB_USERNAME` / `DOCKERHUB_TOKEN` secrets to the
      billing GitHub repository (same values as the other four).
- [ ] After the first push to `main` of each service repo: Docker Hub shows the
      tag with **two** architectures (`linux/amd64`, `linux/arm64`).
- [ ] On the new server: `kubectl get pods -n moment-forever-dev` shows no
      `CrashLoopBackOff` with `exec format error` in the logs.

## D. Credentials — rotate everything that was in Git (console / you)

Each of these is readable by anyone with access to this repo's history, so
each gets a **new** value, entered only in `.env` on the server:

- [ ] PostgreSQL password (was `groote`).
- [ ] `JWT_SECRET` (platform + gateway share it; the script does this).
- [ ] Google OAuth client secret (`GOOGLE_OIDC_CLIENT_SECRET`) — reset in
      Google Cloud Console → Credentials.
- [ ] Brevo SMTP password (`SMTP_PASSWORD`) — regenerate in Brevo.
- [ ] Razorpay test keys and webhook secret — regenerate in the Razorpay
      dashboard.
- [ ] New: `BILLING_INTERNAL_TOKEN`, `PHONE_OTP_SECRET`, `SUPER_ADMIN_PASSWORD`
      (`openssl rand -base64 32` for the first two).
- [ ] GitHub PAT and Docker Hub token used by the bootstrap: fine to keep if
      they were never committed; otherwise rotate.
- [ ] Old values in Git history: the rotation makes them worthless (simplest;
      recommended). Rewriting history is not needed.

## E. Oracle Cloud and DNS (console)

- [ ] Oracle account created; home region chosen (**open question 4**);
      upgraded to Pay As You Go; budget alert at ₹1.
- [ ] VCN with a public subnet; security list allows TCP 22 (your IP only),
      80 and 443 (anywhere).
- [ ] Reserved public IP created.
- [ ] `VM.Standard.A1.Flex` instance, 4 OCPU / 24 GB, Canonical Ubuntu 24.04
      (aarch64), 100 GB boot volume, SSH key, reserved IP attached.
- [ ] GoDaddy DNS: `A` records `api.dev`, `argocd.dev` and `dashboard.dev` →
      the reserved IP (subdomains of `decevent.com`; nothing to buy).
- [ ] Object Storage bucket `moment-forever-backups` (for phase 2).

## F. External services that know our hostname (console)

- [ ] Google Cloud Console → OAuth client: add the website's address to
      authorised JavaScript origins and the redirect URI the frontend uses.
- [ ] Razorpay dashboard → Webhooks: URL
      `https://api.dev.decevent.com/api/payment/webhooks/razorpay` with the
      new webhook secret; events `payment_link.paid`, `payment_link.expired`,
      `payment_link.cancelled`, `payment.failed`, `payment.captured` (the
      five the Payment service handles).
- [ ] **(you)** Confirm or change the two frontend addresses in Git:
      `CORS_ALLOWED_ORIGINS` (`clusters/dev/gateway/configmap.yaml`) and
      `RAZORPAY_CALLBACK_URL` (`clusters/dev/payment/configmap.yaml`) —
      **open question 2**.
- [ ] Brevo: sender address `MAIL_FROM_ADDRESS` verified for `decevent.com`.

## G. First deployment and switch-off (you)

- [ ] Commit and push sections A–C (infra repo + the five service repos). Argo
      CD reads GitHub, so nothing deploys until this is pushed.
- [ ] Run the deployment guide end to end on the new server.
- [ ] Test the full customer journey (sign-up by phone and by email, book,
      pay in Razorpay test mode, receive the confirmation, download the receipt).
- [ ] **Load test** (decision D18, sizing document §8): k6 at 100 and 200
      requests/second for 10 minutes against the real server, including the
      image scenario; record p95 latency, errors, restarts and memory in the
      sizing document. **This is what decides D17 (CDN or not).**
- [ ] AWS is already off: confirm the instance is *terminated* (not stopped),
      the Elastic IP released and no volumes left (cost doc §3), so nothing
      bills once the credits end.

## H. Phase 2 (after the first successful deployment)

- [ ] Nightly backup CronJob: `pg_dumpall` + `mongodump` → Oracle Object
      Storage via `rclone` (S3-compatible endpoint); keep 14 days.
- [ ] A one-page restore drill, tested once.
- [ ] Decide on a lightweight uptime check (free: UptimeRobot / Better Stack
      free tier hitting `https://api.dev.decevent.com/api/platform/actuator/health`).
- [ ] **Images off the server (D17) — only if the load test says so.** The
      options, cheapest first: (1) an NGINX disk cache on our server for
      `/api/platform/public/images/fetch/*` (no new vendor, Java and MongoDB
      are hit once per image, still our bandwidth); (2) Cloudflare R2 (free
      bucket with CDN and custom domain built in) + `app.image.use-cdn=true`
      in Platform + un-commenting the custom endpoint lines in Platform's
      `S3Config` (they are commented out today, so the S3 switch only works
      against real AWS). Oracle's own Object Storage cannot be given our
      domain name, so it is not the right bucket for this.

---

## Open questions (answers needed before the matching box can be ticked)

1. **Hostnames.** `api.dev.decevent.com`, `argocd.dev.decevent.com` and
   `dashboard.dev.decevent.com` are now in the manifests. They are subdomains
   of `decevent.com` — free, created as DNS records; `api.decevent.com` stays
   free for go-live. To change them: the three ingress files + `.env`.
2. **Frontend.** Is there a website and/or a mobile app, where is its code,
   and what address will it have? Needed for `CORS_ALLOWED_ORIGINS`,
   `RAZORPAY_CALLBACK_URL` and the Google OAuth origins (F). Explained in
   plain English in the decisions document, section 8.
3. **Are the GitHub repositories public or private?** Both work with the new
   CI (ARM images are built through QEMU on the normal runner). Public repos
   get unlimited CI minutes; private ones have 2,000 free minutes a month,
   which five services at ~8 minutes a build will not exhaust.
4. **Oracle home region.** Mumbai (`ap-mumbai-1`) or Hyderabad
   (`ap-hyderabad-1`) are closest to customers; both are often short of free
   ARM capacity (what that means and what we do is in the decisions document,
   section 6). The home region cannot be changed later.
5. **What is in the 1 million requests a day?** The sizing assumes 70% API
   calls and 30% image downloads, with 40% of the day's traffic in a 4-hour
   evening peak. The load test should use the real mix if you know it.
