# Cost: before and after

**Who this is for:** anyone who needs to know what the infrastructure costs,
where the saving comes from, and what will start costing money later.

All prices are **approximate list prices as of November 2026**, converted at
about ₹84 per US dollar. The AWS "before" figure should be checked against the
actual AWS bill; the Oracle "after" figure is ₹0 by design and is verified by
a budget alert.

---

## 1. Before: AWS (what it was costing)

One `t3.large` server (2 vCPU, 8 GB RAM) running 24 hours a day. It ran on
**$200 of AWS free credits**, so no cash left the company while they lasted —
but at this rate the credits cover roughly **three months**, after which the
figures below become a real bill. The server is now switched off. The
"saving" in this document is therefore the money we *avoid* paying from here
on, not money already spent.

| Item | What it is | Monthly (USD) | Monthly (₹) |
|---|---|---|---|
| EC2 `t3.large`, on-demand | The rented computer itself. $0.083–0.093 per hour × 730 hours, depending on region. | $61–68 | ₹5,100–5,700 |
| EBS disk, 30 GB | The server's hard disk. | $2.4–3 | ₹200–250 |
| Public IPv4 address | AWS charges for every public IP since February 2024. | $3.65 | ₹310 |
| Data transfer out | Traffic to users. Tiny at our volume; first 100 GB free. | ~$0 | ~₹0 |
| **Total** | | **≈ $67–75** | **≈ ₹5,600–6,300** |

**Per year: roughly ₹70,000.** For a *test* environment that is idle most of
the day.

Things that were already free and stay free: GitHub (code + CI), Docker Hub
(images), Let's Encrypt (HTTPS certificates), Brevo (email, up to 300 a day),
Razorpay test mode, Consul/Kafka/Redis/MongoDB/PostgreSQL (open-source
software run by us).

---

## 2. After: Oracle Cloud Always Free

| Item | Free-tier limit | What we use | Monthly |
|---|---|---|---|
| ARM server `VM.Standard.A1.Flex` | 4 cores and 24 GB RAM in total, forever | 1 server with all 4 cores and 24 GB | **₹0** |
| Block storage (disk) | 200 GB in total (minimum 50 GB per disk) | 100 GB boot disk | **₹0** |
| Reserved public IP | Public IPs are not charged on Oracle | 1 | **₹0** |
| Outbound data transfer | 10 TB a month | ~1.5 TB a month at 1M requests a day, images included — well inside the free amount | **₹0** |
| Object Storage (backups, phase 2) | 20 GB | Nightly database dumps ~1–2 GB | **₹0** |
| Monitoring, budget alerts, notifications | Included | 1 budget alert | **₹0** |
| CDN for images (Cloudflare / R2 free plans) | Free | **Not used for now** (decision D17: decided after the load test). On Oracle a CDN would save server capacity, not money. | **₹0** |
| **Total** | | | **₹0** |

Everything else is unchanged and free: GitHub Actions, Docker Hub, Let's
Encrypt, Brevo, Razorpay test mode.

The one recurring cost that remains is the **domain renewal at GoDaddy**
(`decevent.com` and `decevent.in`, roughly ₹1,000–2,000 a year each). We
already pay this and it is not an infrastructure cost.

---

## 3. Where the saving comes from

| Saving | How much | How |
|---|---|---|
| The server itself | ₹5,100–5,700 / month | Oracle gives a *bigger* server (24 GB vs 8 GB) for free. This is the whole saving, really. |
| Public IP | ₹310 / month | Oracle does not charge for public IPs. |
| Disk | ₹200–250 / month | 100 GB is inside the free allowance. |
| Fitting in the free box | Not money directly, but it is **why the stack fits** in the free server with room to spare: one MongoDB instead of two, and a memory limit on everything. | See [SIZING-FOR-1M-REQUESTS-A-DAY.md](SIZING-FOR-1M-REQUESTS-A-DAY.md). |
| Smaller Docker images | Faster deployments, less disk. | The runtime image currently includes Maven (a build tool) — about 300 MB that is never used. Switching to a Java-runtime-only image roughly halves each image. |

**Total: about ₹6,000 a month, ₹70,000 a year, down to ₹0.**

> **The AWS server is already off, but "off" is not "free".** A *stopped*
> instance still pays for its disk, and an unattached Elastic IP is charged
> ~₹310 a month. Once the credits are gone those become real charges. Check
> once:
>
> 1. AWS console → EC2 → the instance is *terminated*, not merely stopped.
> 2. EC2 → Elastic IPs → `15.134.55.225` is *released*.
> 3. EC2 → Volumes and Snapshots → nothing left over.
> 4. Billing → the current month shows $0 (credits or not).

---

## 4. What would cost money later

None of this is needed for the end-to-end test. Listed so nobody is surprised
at go-live.

| When | What | Rough monthly cost |
|---|---|---|
| If Oracle ended the free tier | The same server at Oracle's paid rate: 4 cores × $0.01/h + 24 GB × $0.0015/GB/h | ≈ $55 (₹4,600) — still cheaper per GB than the old AWS box |
| Go-live, basic | A second small server or managed PostgreSQL so a database restart is not an outage — **needed at 1M requests a day**, where users notice every blip | ₹2,000–4,000 |
| Go-live, with real traffic | Monitoring (Grafana Cloud free tier is usually enough). A CDN for images, if the load test shows it is needed (D17), is also free (Cloudflare). | ₹0–2,000 |
| Per use, any time | SMS login codes and booking SMS: ₹0.15–0.25 per message (2Factor/MSG91) | ~₹100 for 500 messages |
| Per use, any time | WhatsApp booking messages via Meta Cloud API: per 24-hour conversation, India "utility" rate | ~₹0.1–0.3 each |
| Per use, any time | Email above 300 a day (Brevo paid plan) | from ~₹1,500 |
| Per transaction | Razorpay fees on live payments (not infrastructure) | ~2% of each payment |

**Realistic go-live infrastructure bill: ₹3,000–6,000 a month**, against the
₹6,000 a month we were paying for a test box.

---

## 5. How we make sure the bill really is ₹0

- The Oracle account is upgraded to Pay As You Go (see decision D4 in
  [CLOUD-MOVE-DECISIONS.md](CLOUD-MOVE-DECISIONS.md)); free-tier resources
  remain free, but it removes the "idle server reclaimed" and "no capacity"
  problems.
- A **budget alert of ₹1** is set in Oracle (Billing → Budgets). Any charge at
  all sends an email.
- We only ever create resources listed in the free-tier table above. In
  particular: **no second ARM server, no disk above 200 GB total, no load
  balancer above the free one, no Autonomous Database.**
- The Oracle "Cost analysis" page is checked once a month alongside the AWS
  bill until AWS reads $0.
