# Deployment guide — any cloud, step by step

**Who this is for:** anyone. If you can use a web browser and copy-paste
commands into a terminal, you can deploy Moment Forever with this guide. It
takes about **two hours** the first time, most of it waiting.

> **Status (November 2026).** The scripts and manifests in this repository do
> what this guide says. What is still open — accounts to create, keys to
> rotate, the frontend address — is listed in
> [MIGRATION-CHECKLIST.md](MIGRATION-CHECKLIST.md). Nothing deploys until the
> repository changes are pushed to GitHub: Argo CD reads GitHub, not a laptop.

**How it fits together, in one paragraph.** You rent one Linux computer from
a cloud provider and give it a fixed public address. You point two names from
our domain at that address. You log in once, fill in one settings file, and
run one script. The script installs a small Kubernetes (k3s), the HTTPS front
door, and Argo CD. From then on Argo CD reads *this Git repository* and keeps
the server matching it. Nobody deploys by hand again: pushing code to GitHub
is the deployment.

---

## 0. Before you start

You need:

| Item | Where to get it | Why |
|---|---|---|
| A terminal with `ssh` | Windows: PowerShell or Git Bash. Mac/Linux: Terminal. | To log in to the server. |
| An SSH key pair | `ssh-keygen -t ed25519` (press Enter for all questions). Your **public** key is in `~/.ssh/id_ed25519.pub`. | The cloud puts your public key on the server so only you can log in. |
| Access to the Oracle Cloud account | Ask the account owner. | To create the server. |
| Access to the GoDaddy account for `decevent.com` | Ask the account owner. | To point the names at the server. |
| A GitHub personal access token (PAT) | GitHub → Settings → Developer settings → Fine-grained tokens. Repository: `moment-forever-infra`. Permissions: **Contents: read and write**. | Argo CD reads this repo; Image Updater writes new image tags into it. |
| Docker Hub username + access token | hub.docker.com → Account settings → Security → New access token (read-only is enough). | Image Updater checks Docker Hub for new images. |
| The secret values listed in §4 | From the people who own each service (Google, Brevo, Razorpay, SMS provider). | The services won't start without them. |

Terms: a **VM** or **instance** is a rented computer. **SSH** is the secure
way to open a terminal on it. **DNS** maps a name to an address. **k3s** is a
small Kubernetes; **Kubernetes** runs our containers and restarts them if they
die. **Argo CD** keeps the server matching Git. More in
[DEVOPS-TERMINOLOGY-GLOSSARY.md](DEVOPS-TERMINOLOGY-GLOSSARY.md).

---

## 1. Create the server (the only cloud-specific part)

Whatever the provider, you need exactly four things:

1. A Linux server: **Ubuntu 24.04**, **4 cores, 24 GB RAM, 100 GB disk**
   (an ARM processor is fine — our images are built for both).
2. A **fixed public IP address** attached to it.
3. The cloud firewall allowing **TCP 22** (SSH, ideally from your IP only),
   **TCP 80** and **TCP 443** (web, from anywhere).
4. Your SSH public key installed on it.

### 1A. Oracle Cloud (our choice — free)

1. **Sign in** at cloud.oracle.com. If the account is new: Billing → *Upgrade
   to Pay As You Go* (keeps free-tier resources free, avoids "out of capacity"
   and idle reclaim — decision D4). Then Billing → Budgets → create a budget
   of ₹1 with an email alert.
2. **Network.** Menu → Networking → Virtual Cloud Networks → *Start VCN
   Wizard* → *Create VCN with Internet Connectivity* → name `moment-forever` →
   Next → Create. Open the new VCN → *Security Lists* → *Default Security
   List* → *Add Ingress Rules*, three rules, all **Source CIDR**, **TCP**:
   - `0.0.0.0/0` destination port `80`
   - `0.0.0.0/0` destination port `443`
   - (22 from anywhere is already there; tighten it to *your IP*/32 if you
     have a fixed one.)
3. **Fixed IP.** Networking → IP Management → *Reserved Public IPs* → Create.
   Name `moment-forever-ip`. Write the address down: this is `PUBLIC_IP`.
4. **Server.** Compute → Instances → *Create Instance*:
   - Name: `moment-forever-dev`
   - Image: *Change image* → **Canonical Ubuntu 24.04** (pick the **aarch64**
     build when asked)
   - Shape: *Change shape* → **Ampere** → `VM.Standard.A1.Flex` → **4 OCPUs,
     24 GB**
   - Networking: the `moment-forever` VCN, its **public** subnet, *Assign a
     public IPv4 address*: **No** (we attach the reserved one next)
   - SSH keys: *Paste public key* → contents of `~/.ssh/id_ed25519.pub`
   - Boot volume: *Specify a custom boot volume size* → **100 GB**
   - Create. If you see **"Out of host capacity"**: Oracle has no free ARM
     machines in this region right now. Nothing is charged and nothing is
     broken; the server simply isn't created. Retry in a few hours (capacity
     comes and goes during the day), try the shape with 2 OCPUs/12 GB
     temporarily and resize later, or try another availability domain. Pay
     As You Go accounts (step 1) get priority, which is the main reason we
     upgrade. This is the one common annoyance with Oracle's free ARM tier,
     and Mumbai and Hyderabad are both busy regions.
5. **Attach the IP.** Open the instance → *Attached VNICs* → the VNIC →
   *IPv4 Addresses* → the private IP row → ⋮ → *Edit* → Public IP type
   **Reserved** → pick `moment-forever-ip` → Update.
6. **Test:** `ssh ubuntu@<PUBLIC_IP>` — you should get a prompt. Type `exit`.

### 1B. Any other provider

The same four things, different names:

| | Oracle | AWS | Google Cloud | Azure | Hetzner / DigitalOcean |
|---|---|---|---|---|---|
| Server | Compute Instance | EC2 Instance | Compute Engine VM | Virtual Machine | Server / Droplet |
| Fixed IP | Reserved Public IP | Elastic IP | Static external IP | Public IP (static) | Primary IP / Reserved IP |
| Cloud firewall | Security List / NSG | Security Group | Firewall rules | Network Security Group | Firewall |
| Ubuntu login user | `ubuntu` | `ubuntu` | your username | your username | `root` |
| Free tier big enough for us? | **Yes** (24 GB) | No (1 GB) | No (1 GB) | No (1 GB) | No free tier (~€8/mo for 8 GB) |

Everything from §2 onwards is identical.

---

## 2. Point the domain at the server

We own `decevent.com`. That automatically includes **every name under it** —
`api.decevent.com`, `api.dev.decevent.com`, `anything.decevent.com`. These are
called *subdomains*; there is nothing to buy. You create one by adding a DNS
record at GoDaddy, and you can add as many as you like for free.

At GoDaddy → My Products → `decevent.com` → DNS → *Add new record*, three times:

| Type | Name | Value | TTL | Becomes |
|---|---|---|---|---|
| A | `api.dev` | `<PUBLIC_IP>` | 600 | `api.dev.decevent.com` — the API |
| A | `argocd.dev` | `<PUBLIC_IP>` | 600 | `argocd.dev.decevent.com` — Argo CD |
| A | `dashboard.dev` | `<PUBLIC_IP>` | 600 | `dashboard.dev.decevent.com` — Kubernetes Dashboard |

Wait 5–10 minutes, then check from your laptop:
`nslookup api.dev.decevent.com` should print the IP. Don't continue until it
does — the HTTPS certificate step needs it.

(`decevent.in` is not used for now; later it can forward to `.com`.)

---

## 3. Log in and get the repo

```bash
ssh ubuntu@<PUBLIC_IP>
sudo apt-get update && sudo apt-get install -y git
git clone https://github.com/ForeverMoment-Corp/moment-forever-infra.git
cd moment-forever-infra/bootstrap/k3s
```

If the repo is private, `git clone` asks for your GitHub username and the PAT
as the password.

---

## 4. Fill in the settings file (`.env`)

```bash
cp env.example .env
nano .env          # edit, Ctrl+O to save, Ctrl+X to exit
```

Every value, in plain English. **Required** means the bootstrap refuses to
run without it.

### Server and names

| Variable | Required | What to put | Plain English |
|---|---|---|---|
| `PUBLIC_IP` | yes | the reserved IP from §1 | Where the server is. |
| `APP_HOST` | yes | `api.dev.decevent.com` | The API's web address. |
| `ARGOCD_HOST` | yes | `argocd.dev.decevent.com` | Argo CD's web address. |
| `DASHBOARD_HOST` | yes | `dashboard.dev.decevent.com` | The Kubernetes Dashboard's web address. |
| `LETSENCRYPT_EMAIL` | yes | a real team email | Let's Encrypt sends certificate-expiry warnings here (it never needs to; renewal is automatic). |
| `LOG_RETENTION_DAYS` | no | `7` | The weekly cleanup deletes service log files older than this. |

The three hostnames are also written in the manifests
(`clusters/dev/ingress/ingress.yaml`, `clusters/dev/argocd/ingress.yaml`,
`clusters/dev/dashboard/ingress.yaml`). The bootstrap checks that `.env` and
the manifests agree. To use different names, change both and push.

### Git and images

| Variable | Required | What to put | Plain English |
|---|---|---|---|
| `INFRA_REPO_URL` | yes | `https://github.com/ForeverMoment-Corp/moment-forever-infra.git` | This repo. |
| `INFRA_REPO_BRANCH` | yes | `main` | Argo CD follows this branch. |
| `GITHUB_USERNAME`, `GITHUB_TOKEN` | yes | your GitHub user + the PAT from §0 | Lets Argo CD read, and Image Updater write, this repo. |
| `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN` | yes | `groote123` + its access token | Lets Image Updater look up new images. |

### Application secrets (turned into Kubernetes Secrets by `55-create-app-secrets.sh`)

| Variable | Required | What to put | Plain English |
|---|---|---|---|
| `POSTGRES_PASSWORD` | yes | a long random string (`openssl rand -base64 24`) | Database password, shared by the three databases. PostgreSQL reads it only when a database is created for the first time; changing it later is a short procedure (§8). |
| `JWT_SECRET` | yes | `openssl rand -base64 32` | Signs login tokens. Platform and gateway must use the same value (the script does this). |
| `SUPER_ADMIN_EMAIL`, `SUPER_ADMIN_PASSWORD` | yes | the owner's email + a strong password (8+ chars) | The first admin account, created once at start-up. |
| `GOOGLE_OIDC_CLIENT_ID`, `GOOGLE_OIDC_CLIENT_SECRET` | for Google sign-in | Google Cloud Console → Credentials | "Sign in with Google". Leave empty to disable. |
| `PHONE_OTP_SECRET` | yes | `openssl rand -base64 32` | Scrambles SMS login codes in the database. |
| `PHONE_SMS_PROVIDER` | yes | `2factor` (or `msg91`, `exotel`; `none` = phone login off) | Who delivers SMS login codes. |
| `TWOFACTOR_API_KEY` (or `MSG91_AUTH_KEY` + `MSG91_OTP_TEMPLATE_ID`, or the `EXOTEL_*` set) | with the provider above | provider dashboard | The provider's key. Details: Platform repo `docs/PHONE_LOGIN_GUIDE.md`. |
| `SMTP_USERNAME`, `SMTP_PASSWORD`, `MAIL_FROM_ADDRESS` | yes | Brevo → SMTP & API; a sender at `decevent.com` | Booking emails. |
| `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` | yes | Razorpay dashboard (test mode) | Taking payments; checking that webhooks really come from Razorpay. |
| `BILLING_INTERNAL_TOKEN` | yes | `openssl rand -base64 24` | Booking ↔ Billing internal call for receipt PDFs. |
| `BOOKING_SMS_NOTIFICATIONS_ENABLED`, `BOOKING_SMS_PROVIDER`, `BOOKING_SMS_CONFIRMED_TEMPLATE`, `BOOKING_SMS_CANCELLED_TEMPLATE`, `TWOFACTOR_SENDER_ID` | no | see Platform `docs/PHONE_LOGIN_GUIDE.md` §2 | Booking SMS for customers without email. Off by default. |
| `WHATSAPP_API_ENDPOINT`, `WHATSAPP_API_TOKEN` | no | — | WhatsApp messages. Off by default. |
| `SLACK_WEBHOOK_URL` | no | — | Payment alerts to a Slack channel. Off when empty. |

Not in `.env` because they are not secret and live in Git instead:
`GOOGLE_OIDC_CLIENT_ID` (platform ConfigMap), `CORS_ALLOWED_ORIGINS` (gateway
ConfigMap — the website's address) and `RAZORPAY_CALLBACK_URL` (payment
ConfigMap — the frontend page Razorpay returns the customer to).

Keep `.env` on the server only. It is in `.gitignore`; never commit it. Keep a
copy in the team password manager: it is the only thing a rebuild needs (§9).

---

## 5. Run the bootstrap

```bash
chmod +x ./*.sh
./bootstrap-all.sh
```

What happens, in order (each is its own script, so a failed step can be rerun
alone):

| Step | Script | What it does | Takes |
|---|---|---|---|
| 0 | `00-prepare-host.sh` | Checks Ubuntu version, memory, disk and CPU type; installs `curl`, `git`, `jq`. | 1 min |
| 1 | `05-open-host-firewall.sh` | Oracle's Ubuntu images block every incoming connection except SSH *inside the server* (on top of the cloud firewall), which also breaks Kubernetes' own internal traffic. This removes that block so the server behaves like a normal Ubuntu. Does nothing on other clouds. | seconds |
| 2 | `10-install-k3s.sh` | Installs k3s (the mini Kubernetes) with container log rotation. | 1 min |
| 3 | `15-setup-log-cleanup.sh` | Creates `/var/log/moment-forever/<service>` and a timer that runs every Sunday 03:00: deletes log files older than `LOG_RETENTION_DAYS`, trims the system journal, removes unused images. | seconds |
| 4 | `20-install-nginx-ingress.sh` | Installs the front door that receives web traffic on 80/443 (access log off; error log on). | 2 min |
| 5 | `25-install-cert-manager.sh` | Installs the robot that gets free HTTPS certificates from Let's Encrypt and renews them forever. | 2 min |
| 6 | `30-install-argocd.sh` | Installs Argo CD. | 3 min |
| 7 | `40-configure-argocd-repo-access.sh` | Gives Argo CD the GitHub token so it can read this repo. | seconds |
| 8 | `50-install-image-updater.sh` | Installs Image Updater and gives it the Docker Hub token. | 2 min |
| 9 | `55-create-app-secrets.sh` | Turns the secret values in `.env` into Kubernetes Secrets (stops with a clear message if a required one is empty). | seconds |
| 10 | `60-bootstrap-moment-forever.sh` | Checks DNS, that the Secrets exist, that your repo copy matches GitHub and that `.env` hostnames match the manifests; then tells Argo CD "manage Moment Forever from Git". Argo creates every application and prints the URLs. | 1 min, then Argo works for ~10 min |

Then Argo CD pulls images and starts things in order: databases and Kafka
first, then the services. The **first start takes 10–15 minutes** (image
downloads + Java warm-up). Watch with:

```bash
kubectl get applications -n argocd            # every row should become Synced / Healthy
kubectl get pods -n moment-forever-dev -w     # Ctrl+C to stop watching
```

A pod showing `ContainerCreating` or `0/1 Running` for a few minutes is normal
during the first start. `CrashLoopBackOff` after 10 minutes is not — see §10.

---

## 6. Check it worked

| Check | How | Expected |
|---|---|---|
| Certificates | `kubectl get certificate -A` | Every row `READY: True` (may take 2–3 minutes after the ingress appears). |
| API alive | in a browser: `https://api.dev.decevent.com/api/platform/actuator/health` | `{"status":"UP"}` with a padlock, no warning. |
| All services alive | same URL with `booking`, `payment`, `billing` in place of `platform` | `UP` for each. |
| Argo CD UI | `https://argocd.dev.decevent.com` — user `admin`, password from `kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' \| base64 -d; echo` | A tree of green applications. Change the password after first login (User Info → Update password). |
| Kubernetes Dashboard | `https://dashboard.dev.decevent.com` — choose *Token*, paste the output of `kubectl -n kubernetes-dashboard create token viewer` (view-only, valid 1 hour; rerun for a new one); pick namespace `moment-forever-dev` top-left | Deployments and pods, all green. This token can look but not change anything (`clusters/dev/dashboard/README.md`). |
| Receipts database is a replica set | `kubectl logs job/mongo-init -n moment-forever-dev` | Ends with `done` or `already initialised`. |
| The website will be allowed to call the API (CORS) | `curl -sI -H "Origin: https://www.decevent.com" https://api.dev.decevent.com/api/platform/actuator/health \| grep -i access-control` | A line `access-control-allow-origin: https://www.decevent.com`. If the website lives elsewhere, add it to `CORS_ALLOWED_ORIGINS` (§8). |
| First login | `POST https://api.dev.decevent.com/api/platform/auth/login` with `SUPER_ADMIN_EMAIL` / `SUPER_ADMIN_PASSWORD` | A token. The super-admin was created by the seeder at start-up. |
| Phone login code | `POST …/api/platform/auth/phone/otp` with your number | An SMS arrives (if `PHONE_SMS_PROVIDER` is set). |
| Payment webhook reachable | Razorpay dashboard → Webhooks → *Test* | 200 in the Razorpay log. |
| It copes with our traffic | Run the load test in [SIZING-FOR-1M-REQUESTS-A-DAY.md](SIZING-FOR-1M-REQUESTS-A-DAY.md) §8 (k6 from a laptop, ~30 minutes) | p95 under 500 ms at 100 requests/second, no pod restarts. |

Then run the customer journey in the runbook (`docs/runbook/03-customer-journey.md`
at the workspace root): catalog → book → pay (Razorpay test card) → confirmation
→ complete → receipt.

---

## 7. How a code change reaches the server (nobody deploys by hand)

```text
 developer pushes to main
   └─▶ GitHub Actions: tests, builds the Docker image (ARM + Intel), pushes groote123/<service>:<commit-sha>
         └─▶ Argo CD Image Updater (on the server, every 2 min): "new tag on Docker Hub?"
               └─▶ writes the tag into clusters/dev/<service>/kustomization.yaml and commits to this repo
                     └─▶ Argo CD (every 3 min): "repo changed?" → applies it → Kubernetes starts the new version,
                           waits until it is healthy, then stops the old one
```

Typical time from push to live: **10–15 minutes**. To watch it: Argo CD UI →
the application → *History*; or `git log` in this repo (Image Updater's
commits are named `build: automatic update of …`).

---

## 8. Everyday tasks

All on the server (`ssh ubuntu@<PUBLIC_IP>`). `-n moment-forever-dev` means
"in our namespace".

| I want to… | Command |
|---|---|
| See what is running and whether it restarts | `kubectl get pods -n moment-forever-dev` — or in a browser: the Dashboard (§6) → namespace `moment-forever-dev` → *Pods* / *Deployments* |
| Read a service's log | `kubectl logs -n moment-forever-dev deploy/booking --tail=200 -f` (Ctrl+C to stop) |
| Read the log of a pod that crashed | `kubectl logs -n moment-forever-dev <pod-name> --previous` |
| Restart a service | `kubectl rollout restart deploy/payment -n moment-forever-dev` |
| See memory/CPU per service | `kubectl top pods -n moment-forever-dev` |
| Roll back a service to a previous build | Edit `clusters/dev/<service>/kustomization.yaml` in Git, set `newTag` to the older commit SHA (from `git log`), push. Argo rolls back in ~3 min. Image Updater will not move it forward again until a *newer* image appears. |
| Change a non-secret setting (e.g. hold minutes) | Edit the service's `configmap.yaml` in Git, push. Then restart the service (ConfigMap changes don't restart pods by themselves). |
| Allow the website to call the API (CORS) | Add its address to `CORS_ALLOWED_ORIGINS` in `clusters/dev/gateway/configmap.yaml` (comma-separated, no spaces), push, restart `gateway`. Same for the page Razorpay returns to: `RAZORPAY_CALLBACK_URL` in `clusters/dev/payment/configmap.yaml`. |
| Change or rotate a secret | Edit `.env` on the server, run `./55-create-app-secrets.sh`, restart the affected service. |
| Change the database password | PostgreSQL only reads `POSTGRES_PASSWORD` when a database is first created. Afterwards: `kubectl exec -it -n moment-forever-dev postgres-platform-0 -- psql -U postgres -c "ALTER USER postgres PASSWORD 'new'"` (repeat for `postgres-booking-0` and `postgres-payment-0`), then put the new value in `.env`, run `./55-create-app-secrets.sh`, restart platform, booking and payment. |
| Look at a service's log files on disk | `ls -lh /var/log/moment-forever/booking/` — the services' own rolling log files (SQL, Kafka, security, ...). Cleaned weekly; `sudo /usr/local/sbin/moment-forever-log-cleanup.sh` runs the cleanup now. `systemctl list-timers moment-forever-log-cleanup.timer` shows the next run. |
| Open a database shell | `kubectl exec -it -n moment-forever-dev postgres-platform-0 -- psql -U postgres -d moment_forever_db` (`postgres-booking-0` / `moment_forever_book`, `postgres-payment-0` / `moment_forever_payment`) |
| Open a MongoDB shell | `kubectl exec -it -n moment-forever-dev mongo-0 -- mongosh` |
| Full admin in the Dashboard, once | `clusters/dev/dashboard/README.md` — apply `optional-admin-user.yaml`, take a 30-minute token, delete it afterwards. |
| Renew the HTTPS certificate | Nothing — cert-manager renews it automatically 30 days before expiry. |
| Check disk space | `df -h /` (keep under 70%) |
| Free disk space | `sudo /usr/local/sbin/moment-forever-log-cleanup.sh` (old logs + unused images) |
| Pause automatic deployments for one service | Argo CD UI → application → *App Details* → turn off *Auto-sync*. Turn it back on when done. |
| Update k3s / Argo CD themselves | Rare. Rerun the matching bootstrap script after bumping the version URL in `.env`. |

---

## 9. Rebuilding from scratch (disaster recovery)

If the server is lost, or you want a clean start:

1. §1 — create a new server and attach the **same reserved IP** (so DNS needs no change).
2. §3 — log in, clone the repo. Copy your saved `.env` back (keep a copy in the team password manager, never in Git).
3. §5 — run the bootstrap. ~30 minutes to a fully running environment.
4. Restore data from the last nightly backup (phase 2 of the checklist describes the backup job and the restore steps).

Because Argo CD rebuilds everything from Git, there is nothing to "remember"
about the old server except `.env` and the data backup.

---

## 10. Troubleshooting

| Symptom | Most likely cause | Fix |
|---|---|---|
| `ssh` times out | Cloud firewall doesn't allow 22 from your IP, or wrong IP | Check the security list / security group; check `PUBLIC_IP`. |
| Bootstrap stops: "Required variable … is missing" | `.env` not filled | Fill the value, rerun that script. |
| Bootstrap stops: "Local checkout is not the same as origin/main" | You changed files locally without pushing | Argo reads GitHub, not your copy. `git pull` (or commit and push), rerun `60-…`. |
| Certificate stays `READY: False` for > 10 min | Port 80 not reachable from the internet, or DNS not pointing here yet | `nslookup api.dev.decevent.com` must show `PUBLIC_IP`. Check **both** firewalls: cloud (security list) and the OS one (`sudo iptables -L INPUT -n`). `kubectl describe challenge -A` shows Let's Encrypt's reason. |
| Browser warns about the certificate | Still on the staging issuer, or not issued yet | `kubectl get certificate -A`; see above. |
| Pod in `CrashLoopBackOff`, log says `exec format error` | Image built for Intel only (an old tag from before the multi-arch CI) | Push any commit to that service's `main`; the new build is multi-arch. Check on Docker Hub that the tag lists `linux/arm64`. |
| Pod stays `Pending`, `kubectl describe pod` says `Insufficient memory` | The server has less RAM than the memory requests add up to (~4.5 GB) | Use a bigger server, or lower the `requests` in the Deployments (not the limits). |
| Website shows "CORS" errors in the browser console | The website's address is not in the gateway's allow-list | Add it to `CORS_ALLOWED_ORIGINS` (§8). |
| Argo CD / cert-manager pods `Running` but nothing works on Oracle; logs mention timeouts to `10.43.0.1` | Oracle's built-in firewall rules still present | Rerun `./05-open-host-firewall.sh`, then `sudo systemctl restart k3s`. |
| Pod in `CrashLoopBackOff`, log mentions `Connection refused` to postgres/kafka/mongo | Database not ready yet, or wrong host name in the ConfigMap | Wait 2 minutes; if it persists, `kubectl get pods` — is `postgres-0`/`kafka-0`/`mongo-0` Running? |
| Pod in `CrashLoopBackOff`, log mentions a missing property or `null` secret | A `.env` value is empty | Fill it, rerun `55-…`, restart the service. |
| Billing `CrashLoopBackOff`, log mentions "not a replica set" / transactions | Mongo init job hasn't run | `kubectl get jobs -n moment-forever-dev`; `kubectl logs job/mongo-init -n …`. |
| `ImagePullBackOff` | Docker Hub rate limit, or image/tag doesn't exist | `kubectl describe pod <name>` shows the reason. Check the tag exists on Docker Hub. |
| Argo app `OutOfSync` and never syncs | Repo credentials wrong | `kubectl get secret moment-forever-infra-repo -n argocd`; rerun `40-…` with a valid PAT. |
| New image on Docker Hub but nothing deploys | Image Updater can't see or write | `kubectl logs -n argocd deploy/argocd-image-updater-controller --tail=300` — look for the service name; PAT needs *Contents: write*. |
| Everything slow / a pod `OOMKilled` in `kubectl describe pod` | Memory limit hit | See [SIZING-FOR-1M-REQUESTS-A-DAY.md](SIZING-FOR-1M-REQUESTS-A-DAY.md) §6–7. |
| Oracle: "Out of host capacity" | No free ARM capacity right now | Retry later / smaller shape temporarily / Pay As You Go upgrade (decision D4). |

Deeper debugging commands: [KUBERNETES-ARGOCD-DEEP-DIVE-RUNBOOK.md](KUBERNETES-ARGOCD-DEEP-DIVE-RUNBOOK.md).
