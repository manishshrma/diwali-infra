# Sizing for 1 million requests a day — will the free server cope?

**Who this is for:** whoever is responsible for the environment staying up,
and anyone who wants to know whether a free server can really carry this.

**Short answer:** yes for the API traffic, *provided* the changes in this
document are made — fixed memory per service, log levels at INFO, a rate
limit at the front door, and a load test before we trust it. The manifests
now contain all of these. At this volume the server is no longer idle; it
has roughly 3–5× headroom at the assumed peak rather than 100×. The one open
question is image serving (§4, item 1): the load test decides whether images
need to move to a CDN. Going live at this traffic on a single server also
means every database restart is visible to users, so a second server is a
go-live item, not a test-phase item.

---

## 1. What "1 million requests a day" means

| Measure | Value | Note |
|---|---|---|
| Average | **~12 requests per second** | 1,000,000 ÷ 86,400 seconds |
| Assumed peak | **~30 requests per second** | if 40% of the day's traffic lands in a 4-hour evening window |
| **Design target** | **100 requests per second sustained, 200 in short bursts** | a 3× safety factor on the assumed peak |
| Assumed mix | **70% API calls** (catalog lists, details, search, availability; ~5 KB each) · **30% images** (~150 KB each) | *Assumption — see open question 5 in the checklist.* |
| Bookings | A few hundred a day at most | One booking ≈ 10 API calls and ~8 Kafka events. Kafka traffic is a rounding error. |
| Data out | ~3.5 GB/day of JSON + ~45 GB/day of images ≈ **1.5 TB/month** | Inside Oracle's free 10 TB/month. A CDN would cut the server's share to ~10%, but on Oracle that is a capacity question, not a cost one (D17). |

What matters at this scale, in order:

1. **Images.** Every picture goes Gateway → Platform → MongoDB today. Redis
   caches only the picture's *address*; the bytes still stream through Java.
   Platform has 50 request threads, so three first-time visitors opening a
   20-thumbnail list at the same moment can make a fourth visitor's booking
   call wait. Two things soften this: pictures are resized at upload (320 px
   thumbnails, 1280 px heroes), and browsers cache each one for a year, so
   only *first-time* visitors cost a download. Whether that is enough is
   measured in the load test (§8); if not, decision D17 moves images to a CDN.
2. **Cache hit rate.** Catalog browsing is the bulk of API traffic; it must
   come from Redis, not PostgreSQL.
3. **Memory discipline** (same as at any scale, but now the services actually
   work, so the heaps must be a bit bigger).
4. **Logging.** Two services log at DEBUG today; at 1M requests that is
   gigabytes of disk a day and measurable CPU.
5. **Abuse.** At this visibility, bots and scrapers appear. A per-IP rate
   limit at the front door is cheap insurance.

---

## 2. Memory budget (24 GB server)

| Component | Memory limit | Java heap (`-Xmx`) | Why this size |
|---|---|---|---|
| gateway | 768 MB | 384 MB | Every request passes through it; routing only, no database. |
| platform | 1.5 GB | 1 GB | Takes most of the traffic: catalog, search, availability, users. Bigger heap = more room for in-memory work per request. |
| booking | 1 GB | 640 MB | Postgres + Kafka + scheduled jobs. |
| payment | 1 GB | 640 MB | Same shape as booking. |
| billing | 1 GB | 640 MB | MongoDB + PDF generation. |
| PostgreSQL × 3 (platform, booking, payment) | 512 MB each (1.5 GB) | — | `shared_buffers` 128 MB each; the catalog database gets the most reads but Redis takes the bulk. Kept separate by team decision (D6). |
| MongoDB (replica set, one node) | 1 GB | — | WiredTiger cache 512 MB. Holds the images (Platform) and the receipts (Billing). |
| Kafka (one broker, KRaft) | 1 GB | 512 MB | Booking events only; hundreds a day. |
| Redis | 512 MB | — | `maxmemory 256mb`, `allkeys-lru`. The catalog cache that absorbs most API reads. |
| Consul | 256 MB | — | Service registry. |
| Kubernetes Dashboard | 256 MB | — | View-only web UI. |
| Argo CD (all parts) + Image Updater | ~1.5 GB | — | Upstream defaults. |
| NGINX ingress + cert-manager | ~0.5 GB | — | NGINX itself handles thousands of requests a second in this budget. |
| k3s itself | ~0.7 GB | — | — |
| **Total reserved** | **≈ 13.5 GB** | | **Leaves ~10 GB free on a 24 GB server.** |

Why the Java heap must be set explicitly (decision D8): a Java program with no
limit takes up to **25% of the whole machine** as heap — 6 GB on this server.
Five services × 6 GB = 30 GB on a 24 GB machine. Setting `-Xmx` per service
through `JAVA_TOOL_OPTIONS` makes every service's appetite fixed and known.
The container limit sits ~50% above the heap because Java also needs memory
outside the heap (threads, class data, native buffers).

### 2.1 "What happens if a service keeps running and tries to use more than its heap?"

Think of the heap as the service's plate. `-Xmx640m` means "your plate holds
640 MB, and you will never be handed a bigger one".

1. **Normally the plate is never full.** Java constantly clears finished
   objects off it (garbage collection). Memory is *reused*, not accumulated —
   a service running for months does not grow just because it has been
   running a long time. Under steady traffic our services should sit at
   40–60% of their plate.
2. **If a burst needs more than fits**, Java first clears the plate harder
   (more garbage collection — the service is a little slower for a few
   seconds). That almost always resolves it.
3. **If even that is not enough**, the *one request* that needed the memory
   fails (`OutOfMemoryError`; that customer sees an error for that call). The
   service keeps serving everyone else. We also set
   `-XX:+ExitOnOutOfMemoryError`, so if this ever happens the service exits
   cleanly and Kubernetes restarts it fresh within seconds instead of limping
   on in a damaged state. With rolling restarts (§5) that is a few seconds
   of errors, not an outage.
4. **At no point does it take memory from anyone else.** The databases,
   Kafka and the other services are untouched. That is what "predictable"
   means: the worst case is one restarted service, never a dead machine.

Second fence: the *container* limit (e.g. 1 GB) sits above the heap (640 MB).
If the whole Java process — heap plus its own bookkeeping — ever exceeds the
container limit, Kubernetes stops that one container and restarts it
(`OOMKilled` in `kubectl describe pod`). Again: one container, not the server.

**Without** fixed heaps, every service quietly grows towards 6 GB, the
machine runs out, and Linux kills *some* process — often a database, because
it is big. That is unpredictable, and it is how single-server setups die.

---

## 3. CPU (4 ARM cores)

Rough cost per request on this hardware:

| Request type | CPU time | At 100 req/s |
|---|---|---|
| Catalog list or detail served from Redis | 2–5 ms (gateway + platform) | 0.2–0.5 core |
| Catalog query that misses the cache (PostgreSQL) | 10–30 ms | only on cache misses; ~10% → 0.1–0.3 core |
| Availability / booking / payment call | 15–40 ms | a few per second → ~0.1 core |
| Image through Java from MongoDB (as deployed) | 20–50 ms + memory churn | 30 req/s → **1–1.5 cores** |
| Image via a CDN (only if the load test says so, D17) | **0 on our server** | the CDN serves it; the origin sees it once |
| NGINX ingress, Consul, Argo CD, k3s | — | ~0.3 core background |

**Estimate at the 100 req/s design target: ~3 cores with images through Java
(as deployed), ~1.5 cores with a CDN.** Three of four cores is tight and
leaves little room for a burst — *if* the assumed image share is right and
*if* browser caching does not absorb most of it. That is exactly what the
load test (§8) measures before anyone spends time on a CDN.

Start-up is still the CPU-hungriest moment (five JVMs compiling at once);
Argo CD sync waves start databases and Kafka first, then the services, and
readiness probes allow 30–60 seconds before the first check. No CPU limits
(they cause stalls on a single node); small CPU *requests* for scheduling.

---

## 4. Changes required at this traffic (beyond the memory table)

| # | Change | Why | Where | Status |
|---|---|---|---|---|
| 1 | **Measure image serving in the load test; move images to a CDN only if it hurts** (decision D17). | Images are the heaviest single load, but Oracle's bandwidth is free and browsers cache each picture for a year, so the real cost is unknown until measured. If needed: NGINX disk cache on the server (cheap), or Cloudflare R2 + `app.image.use-cdn=true` in Platform (checklist H). | Load test §8 | ⏳ after the load test |
| 2 | **Log level INFO** for every service. The services' `logback.xml` files are DEBUG/TRACE for local development; `-Dlogging.level.…=INFO` flags in each ConfigMap's `JAVA_TOOL_OPTIONS` override them without a code change. `SPRING_JPA_SHOW_SQL=false` as well. | At 1M requests DEBUG writes gigabytes a day and costs CPU. | `clusters/dev/*/configmap.yaml` | ✅ |
| 3 | **NGINX ingress access log off** (`disable-access-log: "true"`). | 1M lines a day fills the 10 MB × 3 rotation in minutes anyway. Switch it on temporarily to debug routing (comment in the script). | `bootstrap/k3s/20-install-nginx-ingress.sh` | ✅ |
| 4 | **Per-IP rate limit at the ingress**: `nginx.ingress.kubernetes.io/limit-rps: "20"` on the API ingress (20 requests per second per IP, bursts up to 5× allowed). | A scraper or a bug in a client must not take the API down for everyone. Login and OTP endpoints already have their own limits in the code. | `clusters/dev/ingress/ingress.yaml` | ✅ |
| 5 | **Redis `maxmemory 256mb`, policy `allkeys-lru`.** | The catalog cache must never grow until Redis is killed; LRU keeps the hot entries. | `clusters/dev/shared-infra/redis.yaml` | ✅ |
| 6 | **Platform's database pool 10 → 20 connections** (`SPRING_DATASOURCE_HIKARI_MAXIMUM_POOL_SIZE=20`). | Cache misses at peak should not queue on the pool. The other services stay at 10. PostgreSQL's limit is 100 per server; each service has its own server. | `clusters/dev/platform/configmap.yaml` | ✅ |
| 7 | **Service log files on disk, cleaned weekly.** Each service writes its own log files to `./logs`; the Deployments mount that at `/var/log/moment-forever/<service>` on the server and a weekly timer deletes files older than 7 days. | Without this the files grow inside the container until the disk is full. | Deployments + `bootstrap/k3s/15-setup-log-cleanup.sh` | ✅ |
| 8 | **Load test before trusting it** (§8). | Every number above is an estimate. The test turns it into a fact. | Checklist G | ⏳ |

---

## 5. What keeps things from crashing

| Protection | Where | What it prevents |
|---|---|---|
| Memory limits + fixed Java heap | every Deployment / StatefulSet | A single service eating the machine. |
| Liveness probes | every service | A hung service staying hung — Kubernetes restarts it. |
| Readiness probes + rolling updates | every service | Traffic reaching a service that is still starting. A code deploy starts the new copy first and stops the old one only when the new one is healthy — **zero-downtime deploys even on one server** for the stateless services. |
| `restartPolicy: Always` | everything | A crashed process staying dead. |
| StatefulSets with persistent volumes | PostgreSQL, MongoDB, Kafka | Data loss on restart. |
| Sync waves | Argo CD applications | Services starting before databases. |
| Redis cache (10-minute TTL on catalog lists/details) | Platform | PostgreSQL being hit by every browse. |
| Startup probes (up to 5 minutes) | every service | Kubernetes restarting a service that is merely slow to start when five JVMs boot together on ARM. |
| Browser cache for images (one year, immutable, already in the code) | Platform | Returning visitors downloading the same pictures again. |
| Per-IP rate limit (item 4) | ingress | One client degrading the API for everyone. |
| Transactional outbox + retry jobs (already in the code) | all services | Lost events when Kafka restarts; invisible to users. |
| Automatic certificate renewal | cert-manager | HTTPS expiring. |
| Argo CD self-heal | all applications | Hand edits on the server; Git wins within minutes. |
| Nightly backups (phase 2) | CronJob | Losing the server = losing the data. |

**What this does not protect against:** the server itself going down, or a
database restart. On one server, a PostgreSQL restart is 10–30 seconds of
errors for bookings (browsing from Redis keeps working). Acceptable for the
end-to-end test phase; **not acceptable at go-live with this traffic** — see
§7.

---

## 6. Disk (100 GB)

| What uses disk | Expected size | How it is kept in check |
|---|---|---|
| OS + k3s + container images | ~10 GB | k3s prunes unused images; smaller runtime images help. |
| PostgreSQL data (3 servers) | < 2 GB for years | Cleanup jobs in Platform/Booking/Payment delete old outbox and idempotency rows. |
| MongoDB (images + receipts) | ~5 MB per experience; receipts tiny | Watch `df -h`; a CDN/bucket (D17) would stop the growth if it ever matters. |
| Kafka logs | < 1 GB | Retention 7 days. |
| Container output (`kubectl logs`) | small | k3s rotation 10 MB × 3 per container (recent output only). |
| Service log files (`/var/log/moment-forever/<service>`) | at INFO: 50–200 MB/day per service | Weekly timer deletes files older than 7 days (bootstrap step 15); worst case ~1.5 GB per service. |
| System journal (k3s, sshd) | — | Capped at 300 MB / 7 days by the same step. |
| Backups (local copy before upload) | ~100 MB/night | Last 2 nights kept locally. |

Alert at 70% used.

---

## 7. When to grow, and what "go-live at this traffic" needs

| Signal | Action |
|---|---|
| Any service consistently > 85% of its memory limit (`kubectl top`) | Raise its `-Xmx` and limit by 256 MB. |
| CPU over 3 of 4 cores at peak (`kubectl top nodes`) | Check how much is image serving (`kubectl top pods`: platform vs gateway). If it is images, do D17 (CDN) first — free. Otherwise this is the signal for a second server. |
| Redis hit rate under 85% (`redis-cli info stats`) | Raise the catalog TTL or `maxmemory`. |
| p95 API latency over 500 ms in the load test | Investigate before go-live; usually a missing cache or an N+1 query, not hardware. |
| Disk > 70% | Add a block volume (free up to 200 GB total). |

**Go-live checklist at 1M requests a day** (costs money; not needed for the
test phase): a second server so a database restart is not an outage
(managed PostgreSQL ≈ ₹2,000–4,000/month, or a second free-tier-sized paid
VM ≈ ₹2,500/month), an uptime monitor, and — if the load test showed images
hurting — the CDN from D17 (free).

---

## 8. The load test (do this once before trusting any of the above)

Tool: **k6** (free, one binary, runs from a laptop). Target: the real
`https://api.dev.decevent.com`.

| Scenario | Rate | Duration | Pass if |
|---|---|---|---|
| Catalog browse: list experiences for a city, open 3 details, check availability for a date | ramp 10 → 100 req/s | 10 minutes | p95 < 500 ms; 0 errors; no pod restarts; memory flat after warm-up |
| Burst: same mix | 200 req/s | 2 minutes | p95 < 1 s; errors < 0.5%; recovers within 1 minute |
| Images (through Java, as deployed) | 30 req/s of thumbnail/hero URLs **while** the catalog browse scenario runs | 5 minutes | Catalog p95 still < 500 ms and Platform CPU < 2 cores; otherwise D17 (CDN) is needed before go-live |
| Booking flow (with Razorpay test mode) | 1 booking/s | 5 minutes | every booking reaches `PENDING` with a payment link; no DLT messages |

Record the results in this document under a "Measured" heading, with the
date and commit SHAs, so the estimates above are replaced by numbers.
