# Moving to a free cloud server — the decisions and why

**Who this is for:** everyone on the team, including people who have never
deployed anything. No prior cloud knowledge is needed. Technical words are
explained the first time they appear; the full list is in
[DEVOPS-TERMINOLOGY-GLOSSARY.md](DEVOPS-TERMINOLOGY-GLOSSARY.md).

**Status:** decided on 2026-11-07. The scripts and manifests in this repo are
being changed to match; progress is tracked in
[MIGRATION-CHECKLIST.md](MIGRATION-CHECKLIST.md).

---

## 1. What we are trying to achieve

| Goal | What it means in practice |
|---|---|
| **Test the whole product end to end** before going live | Sign-up, catalog, booking, payment, confirmation message, receipt — all working on a real server with a real `https://` address, not only on laptops. |
| **Pay nothing for now** | Use the permanently free tier of a cloud provider. The current AWS server costs about ₹6,000 a month (see [COST-BEFORE-AND-AFTER.md](COST-BEFORE-AND-AFTER.md)). |
| **Not be tied to one cloud** | The setup scripts must work on any provider's Linux server. Only the "create a server" step is cloud-specific. |
| **Stay stable at our real load** | Up to **1 million requests a day** (about 12 per second on average; we plan for 100 per second at peak). Nothing — database, Kafka, MongoDB or a service — may crash, run out of memory or become slow. |
| **Anyone can deploy and understand it** | A non-technical team member or an intern can follow [DEPLOYMENT-GUIDE-ANY-CLOUD.md](DEPLOYMENT-GUIDE-ANY-CLOUD.md) and get a working environment. |

---

## 2. The short version

We keep the same design we already have (one Linux server running a small
Kubernetes called **k3s**, with **Argo CD** deploying from this Git repo). We
move it from a paid AWS server to **Oracle Cloud's permanently free ARM server
(4 cores, 24 GB RAM)**, make the scripts cloud-neutral, give every part of the
stack a fixed memory budget so it fits with room to spare, add the Billing
service (which was never deployed), keep passwords out of Git, and use our own
domain `decevent.com`. Whether images need a CDN is decided after a load test
(D17), not guessed.

Monthly infrastructure cost goes from about **₹6,000 to ₹0**.

---

## 3. What we had on AWS (plain English)

One rented computer at Amazon ("EC2 instance", type `t3.large`, 8 GB memory)
with a fixed public address (`15.134.55.225`). On it:

```text
 Internet ──> 15.134.55.225 ──> NGINX (front door, HTTPS)
                                   │
                 ┌─────────────────┼──────────────────────┐
                 │  k3s (mini Kubernetes) on one machine  │
                 │                                        │
                 │  gateway → platform / booking / payment│
                 │  3 × PostgreSQL   Kafka   MongoDB      │
                 │  Redis   Consul   Argo CD   Dashboard  │
                 └────────────────────────────────────────┘
```

How a code change reached it: push to GitHub → GitHub Actions builds a Docker
image and pushes it to Docker Hub → **Argo CD Image Updater** writes the new
image tag into this repo → **Argo CD** applies it to the server. That chain is
good and we keep it unchanged.

What was wrong or missing:

- It ran on $200 of AWS free credits. Once those were used up it would have
  cost about ₹6,000 a month for a test environment, so it was switched off.
- Hostnames were based on the IP (`api.15.134.55.225.nip.io`), so they would
  change with the IP, and we don't own `nip.io`.
- The **Billing** service (receipts) was never deployed, so "end to end" was
  not actually possible.
- Passwords and API keys were written in plain text inside this repo.
- Java services had no memory limits, so one busy service could starve the rest.
- The Kubernetes Dashboard was open to the internet with **full administrator**
  rights. Seeing deployments and pods is useful; full admin on a public URL is
  the risk.

---

## 4. The decisions

Each row: what we decided, why, and what it means for you.

| # | Decision | Why | What it means for you |
|---|---|---|---|
| **D1** | **Keep the same design** (k3s + Argo CD on one server) and move it, rather than redesign. | It works, the team knows it, and only three small pieces of it are tied to AWS. Redesigning costs time and gains nothing at our size. | The documents you already know (Argo basics, runbooks) stay valid. |
| **D2** | **Make the setup cloud-neutral.** Everything cloud-specific (create server, open ports, reserve a fixed IP, point the domain) happens in the provider's web console *before* you log in. From the first `ssh` onwards the steps are identical everywhere. | We don't want to redo this work for every provider. Free tiers change; we want to be able to move again in an afternoon. | The guide has one "create a server" section per provider and one shared section for everything else. The scripts never call a cloud API. |
| **D3** | **Host on Oracle Cloud "Always Free" — one ARM server (`VM.Standard.A1.Flex`, 4 cores, 24 GB RAM, 100 GB disk).** | It is the only permanently free offer big enough for our full stack (5 Java services + databases + Kafka need ~13.5 GB at our traffic). Every other provider's free server has 1 GB, which cannot run even one of our services properly. It has **3× the memory** of the AWS server we were paying for. | Zero monthly cost. One account to manage. |
| **D4** | **Upgrade the Oracle account to "Pay As You Go" but stay inside the free limits**, with a budget alert at ₹1. | Purely free-tier accounts get two problems: Oracle may **reclaim an idle server** after 7 days of low usage, and the free ARM capacity is often "out of stock". Pay-As-You-Go removes both, and free-tier resources still cost ₹0. The alert tells us the moment anything is billed. | A card is registered. We expect a ₹0 bill; the alert proves it. |
| **D5** | **Build our Docker images for ARM as well as Intel** (one change in the shared CI workflow). | The free server has an ARM processor. Our images are built for Intel only today and would fail to start on it ("exec format error"). | Nothing changes in day-to-day work; builds take a few minutes longer. |
| **D6** | **Keep three separate PostgreSQL servers** (one per service, as today), each with a memory limit. | Team decision: one service's database must never be affected by another's. The price is about 0.7 GB more memory than a single shared server, which the 24 GB machine absorbs easily. (A single server with three databases would have needed no code change and remains an option later.) | Three small databases to back up; the nightly backup job dumps all three. |
| **D7** | **Run one MongoDB as a single-node "replica set"**, shared by Platform (images) and Billing (receipts). | Billing uses MongoDB transactions, which only work in replica-set mode. Platform doesn't care either way. One MongoDB instead of two. | One MongoDB to back up and watch. |
| **D8** | **Give every container a memory limit and set the Java heap size explicitly.** | By default a Java program claims up to a quarter of the *whole machine's* memory. With 24 GB that is 6 GB per service, five services — a guaranteed crash under load. A fixed heap is a fixed plate: each service can never eat more than its share, so the total is known and the machine can never run out because of one service. What happens if a service *wants* more than its plate is explained in [SIZING-FOR-1M-REQUESTS-A-DAY.md](SIZING-FOR-1M-REQUESTS-A-DAY.md) §2.1. | This is the single most important change for "nothing crashes". |
| **D9** | **Deploy the Billing service.** | It was never deployed on AWS. Without it there are no receipts, and the "test end to end" goal is not met. | Billing gets a CI workflow, manifests and an Argo app like the other services. |
| **D10** | **Use our own domain**: `api.dev.decevent.com` for the API, `argocd.dev.decevent.com` for Argo CD and `dashboard.dev.decevent.com` for the Kubernetes Dashboard. Keep `api.decevent.com` free for go-live. `decevent.in` will later redirect to `.com`. | We own `decevent.com` already. **Owning a domain means owning every name under it for free**: `api.decevent.com`, `api.dev.decevent.com`, `anything.decevent.com` are *subdomains* — nothing to buy, you just add a DNS record at GoDaddy for each. A real domain means certificates, Google sign-in and the Razorpay webhook are configured **once** and stop changing with the IP. `nip.io` is a third-party service and Let's Encrypt limits certificates per hostname to 5 a week, which bites when rebuilding. | Three DNS records at GoDaddy, each free. The `.dev.` part marks this as the test environment so the go-live names stay clean. |
| **D11** | **Keep the Kubernetes Dashboard on a public URL, but with a view-only login.** The everyday token can see deployments, pods, logs and status, but cannot change or delete anything. A full-admin token can still be created on the server by whoever runs `kubectl`, when genuinely needed. | The team wants to watch deployments and pod status in a browser. Today's login is `cluster-admin` on a public URL (runbook item F4): anyone who gets the token can delete the databases. A view-only token gives the same picture with none of that risk. | Dashboard at `https://dashboard.dev.decevent.com`. Get a token with `kubectl -n kubernetes-dashboard create token viewer`. |
| **D12** | **Keep passwords and API keys out of Git.** They live only in the `.env` file on the server and are turned into Kubernetes Secrets by the bootstrap script. **Rotate every key that is currently in the repo.** | Anyone with repo access could read the JWT secret, the Google client secret, the Brevo email password and the Razorpay keys today. | The guide lists every value, in plain English, with where to get it. One file to fill in. |
| **D13** | **Keep the free services we already use**: GitHub Actions (CI), Docker Hub (images), Let's Encrypt (certificates), Brevo (email, 300/day free), Razorpay test mode. | All free at our volume and already working. | No new accounts needed. |
| **D14** | **Nightly backups of PostgreSQL and MongoDB to Oracle Object Storage** (20 GB free). *Phase 2 — after the first successful deployment.* | A single server can be lost. With a nightly dump the whole environment can be rebuilt in under an hour. | Zero cost. |
| **D15** | **Start with fresh data**; do not copy data from the AWS server. | It is test data. Re-seeding the super-admin and catalog is faster than migrating. | The AWS server can be switched off as soon as the new one works. |
| **D16** | **Keep Consul, Kafka and Redis as single instances**, with memory limits. Do not switch to managed/cloud versions. | Kafka only carries booking events (a few hundred a day, even at 1M requests). Redis is the catalog cache that absorbs most reads and gets a proper memory cap. Managed Kafka or managed PostgreSQL would be the first things that cost money. | Nothing to learn anew. |
| **D17** | **Images stay on the server for now; decide on a CDN after the load test.** No Cloudflare, no object storage in the test phase. | Redis caches the *address* of each picture, not the picture: every first-time visitor still downloads the bytes through Gateway → Platform → MongoDB, and Platform has 50 request threads, so three visitors opening a 20-thumbnail list at once can make a fourth visitor's booking call wait. That is a real limit at 1M requests a day — but it is an *estimate*. On Oracle a CDN saves no money (10 TB of traffic a month is free), only server capacity, and the end-to-end test will never see 1M requests a day. So: measure first (D18), then decide. If the test shows images hurting bookings, the clean free route is Cloudflare R2 (a bucket with the CDN and custom domain built in; Oracle's own buckets cannot take our domain name) plus a two-line change in Platform's `S3Config` to allow a non-AWS endpoint. A cheaper middle step is an NGINX disk cache on our server. | Nothing to set up now. The sizing document §4 lists what to watch in the load test and when to revisit. |
| **D18** | **Run a load test before trusting the sizing.** Free tool (k6), one afternoon, against the real server. | Every number in the sizing document is an estimate. A 10-minute test at 100–200 requests per second turns estimates into measured facts and finds slow queries before customers do. | Results are recorded in the sizing document with the date. |

---

## 5. What we are deliberately NOT doing yet

| Not now | Why not | When we would |
|---|---|---|
| More than one server (high availability) | Costs money; our users can tolerate a short outage in a test environment. | At go-live, if we decide downtime is unacceptable. |
| Managed database (Oracle/AWS hosted PostgreSQL) | ~₹2,000–4,000 a month. A nightly backup covers the test phase. | When real customer money is in the database. |
| Autoscaling | One server; our planned peak (~100 requests/second) fits it, to be confirmed by the load test. | When a second server exists. |
| A CDN / object storage for images (D17) | Not needed to test end to end; on Oracle it saves capacity, not money. | After the load test, if images measurably slow bookings — or at go-live. |
| A monitoring stack (Prometheus/Grafana) | Uses 1–2 GB of memory and needs upkeep. For now: `kubectl top`, Argo CD health, the Dashboard and the logs. | When going live. |

---

## 6. Risks we accept, and how we limit them

| Risk | How likely | What we do about it |
|---|---|---|
| **Everything is on one server.** If it dies, the environment is down; a database restart is 10–30 seconds of booking errors (browsing keeps working from the cache). At 1M requests a day, users *will* notice such moments. | Low for the server dying; restarts happen a few times a year. | Fine for the test phase. Nightly backups (D14) + the bootstrap scripts rebuild a server in ~1 hour. Code deploys are already zero-downtime (new copy starts before the old stops). **For go-live at this traffic, a second server or a managed database is required** — see the sizing document §7. |
| **Oracle has no free ARM capacity** in our region when we try to create the server. What happens: the console says "Out of host capacity" and simply does not create the server. Nothing is charged, nothing breaks — we just can't get the machine at that moment. Both Mumbai and Hyderabad are busy regions where this happens often. | Common, but intermittent: capacity frees up at various times of day. | Pay-As-You-Go upgrade (D4) — Oracle gives paid accounts priority for capacity, and our free allowance still applies. Otherwise retry (every few hours; people routinely get one within a day or two), or start with 2 cores / 12 GB and resize later. If after a week there is still nothing, the fallback is a paid ₹2,000–3,000/month server anywhere; D2 makes that a same-day move. |
| **Oracle changes the free tier.** | Unlikely but possible. | D2 means we can move to any ₹2,000–3,000/month server in an afternoon. |
| **ARM-only surprises** (a library or base image without an ARM build). | Low; everything we use has ARM builds. The runtime base image needs a check. | Build images for both ARM and Intel (D5), so moving back to Intel needs no rebuild. |
| **Free tier reclaimed for being idle.** | Only on pure free accounts. | D4. |

---

## 7. The target picture

```text
 Internet ─── https://api.dev.decevent.com ───────┐  (API + images)
         ─── https://argocd.dev.decevent.com ──────┤
         ─── https://dashboard.dev.decevent.com ───┤  (view-only login)
                                                   ▼
            Oracle Cloud · reserved public IP · cloud firewall 22/80/443
            ┌─────────────────────────────────────────────────────────┐
            │  Ubuntu 24.04 · ARM · 4 cores · 24 GB · 100 GB disk     │
            │  .env on the server = the only place secrets live       │
            │  /var/log/moment-forever/<service> · cleaned weekly     │
            │                                                         │
            │  k3s (one node)                                         │
            │   ├─ NGINX ingress (rate limit) + cert-manager (HTTPS)  │
            │   ├─ Argo CD + Image Updater   (deploys from this repo) │
            │   ├─ Kubernetes Dashboard (view-only)                   │
            │   ├─ gateway (CORS) ──▶ platform, booking, payment,     │
            │   │                     billing  — each with a fixed    │
            │   │                     Java heap and memory limit      │
            │   ├─ PostgreSQL × 3 (platform, booking, payment)        │
            │   ├─ MongoDB (1 node, replica set rs0)                  │
            │   ├─ Kafka (1 broker, KRaft)   Redis (256 MB)   Consul  │
            │   └─ nightly backup job ──▶ Oracle Object Storage       │
            │        (phase 2)                                        │
            └─────────────────────────────────────────────────────────┘
                               ▲
   GitHub (code) ─▶ GitHub Actions (build, ARM+Intel) ─▶ Docker Hub ─┘
                     Image Updater writes new tag into this repo ─▶ Argo CD
```

## 8. The frontend — what it is and why we need to know where it lives

Everything in this repo deploys the **backend**: the API that stores bookings,
talks to Razorpay, sends messages. Customers never see it directly. What they
see is the **frontend**: the website pages or the mobile app with the buttons
and forms. The frontend is a separate piece of software that runs **on the
customer's device** (in their browser, or as an installed app) and calls our
API at `api.dev.decevent.com` behind the scenes.

Two things follow:

1. **The frontend has to be hosted somewhere too.** For a website that means
   the HTML/JavaScript files must be served from an address such as
   `www.decevent.com`. Options, all ₹0: on the **same server** (NGINX serves
   the files next to the API — simplest, one less account), or a free static
   host (Cloudflare Pages, Netlify, Vercel, GitHub Pages). A mobile app is
   published through the app stores and needs no hosting.
2. **The API must be told the website's address (CORS).** Browsers have a
   safety rule: a page from `www.decevent.com` may only call an API at a
   *different* address (`api.dev.decevent.com`) if that API explicitly answers
   "yes, I allow `www.decevent.com`". Until now **no service answered that at
   all** (the `cors` block in Platform's configuration was never wired up), so
   a website would have been blocked on every call with a confusing "CORS"
   error. The allow-list now lives in the gateway, the single front door, as
   the setting `CORS_ALLOWED_ORIGINS` in `clusters/dev/gateway/configmap.yaml`.
   It is pre-filled with `https://www.decevent.com` and `https://decevent.com`
   (plus `localhost` for developers); if the website ends up at another
   address, that one line changes. A mobile app is not affected by this rule.
3. **Razorpay sends the customer back to a page after paying.** That page is
   part of the frontend too. The address is the setting `RAZORPAY_CALLBACK_URL`
   in `clusters/dev/payment/configmap.yaml`, pre-filled with
   `https://www.decevent.com/payment/success` until the real one is known.

So the questions are simply: *is there a website, a mobile app, or both; where
is its code; and what address will it have?* The answer confirms (or changes)
two lines and, for a website, one hosting choice (recommended: same server).

Related reading, in order:

1. This document — the *why*.
2. [COST-BEFORE-AND-AFTER.md](COST-BEFORE-AND-AFTER.md) — the money.
3. [SIZING-FOR-1M-REQUESTS-A-DAY.md](SIZING-FOR-1M-REQUESTS-A-DAY.md) — whether the free server copes with 1M requests a day, and what it needs.
4. [DEPLOYMENT-GUIDE-ANY-CLOUD.md](DEPLOYMENT-GUIDE-ANY-CLOUD.md) — the step-by-step *how*.
5. [MIGRATION-CHECKLIST.md](MIGRATION-CHECKLIST.md) — what is done in the repos, what is done by hand in consoles, and the questions still open.
