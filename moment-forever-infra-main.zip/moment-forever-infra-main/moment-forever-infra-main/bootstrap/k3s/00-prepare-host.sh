#!/usr/bin/env bash
# Step 0: check the server and install the few tools the other scripts need.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common.sh"

ensure_root "$@"
load_env
require_ubuntu
warn_if_low_resources

log "Updating APT package index"
apt-get update -y

log "Installing host prerequisites"
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  apt-transport-https \
  ca-certificates \
  curl \
  gettext-base \
  git \
  gnupg \
  jq \
  lsb-release \
  software-properties-common

log "Host preparation finished"
log "Reminder: the CLOUD firewall (Oracle security list / AWS security group / ...) must allow inbound TCP 22, 80 and 443. The next step opens the OS firewall."
