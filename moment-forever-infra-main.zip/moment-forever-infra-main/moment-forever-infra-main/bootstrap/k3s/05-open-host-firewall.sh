#!/usr/bin/env bash
# Step 05: make the operating-system firewall behave like a plain Ubuntu.
#
# Why this exists: Oracle Cloud's Ubuntu images ship iptables rules that
# REJECT every incoming connection except SSH, and REJECT all forwarded
# traffic. That silently breaks two things:
#   1. nobody can reach ports 80/443 (the web front door), and
#   2. pods cannot reach the Kubernetes API on the node, so Argo CD,
#      cert-manager and friends fail in confusing ways.
# AWS, Google, Azure and Hetzner images do not have these rules, so there
# this script finds nothing to do.
#
# The real firewall is the cloud one (security list / security group), which
# only lets 22, 80 and 443 in - exactly as it was on AWS. Safe to run twice.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common.sh"

ensure_root "$@"
load_env

changed=false

# 1. Remove Oracle's blanket REJECT rules from the live rules.
for chain in INPUT FORWARD; do
  while iptables -C "$chain" -j REJECT --reject-with icmp-host-prohibited 2>/dev/null; do
    log "Removing '$chain -j REJECT' rule"
    iptables -D "$chain" -j REJECT --reject-with icmp-host-prohibited
    changed=true
  done
done

# 2. Remove them from the file that is restored at boot, if there is one.
RULES_FILE=/etc/iptables/rules.v4
if [[ -f "$RULES_FILE" ]] && grep -q 'REJECT --reject-with icmp-host-prohibited' "$RULES_FILE"; then
  log "Removing the REJECT rules from $RULES_FILE so they do not come back after a reboot"
  cp "$RULES_FILE" "${RULES_FILE}.bak-$(date +%Y%m%d%H%M%S)"
  sed -i '/REJECT --reject-with icmp-host-prohibited/d' "$RULES_FILE"
  changed=true
fi

# 3. If ufw is active (not the default on cloud images), allow the web ports.
if command_exists ufw && ufw status 2>/dev/null | grep -q '^Status: active'; then
  log "ufw is active: allowing 80/tcp and 443/tcp"
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  changed=true
fi

if [[ "$changed" == "true" ]]; then
  log "OS firewall adjusted."
else
  log "Nothing to change: the OS firewall already allows web traffic."
fi
log "Remember: the cloud firewall still has to allow TCP 22, 80 and 443 (doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md section 1)."
log "To use kubectl from your laptop later, open TCP 6443 in the CLOUD firewall for your IP only."
