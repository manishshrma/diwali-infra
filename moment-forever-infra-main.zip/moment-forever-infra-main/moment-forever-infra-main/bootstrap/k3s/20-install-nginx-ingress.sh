#!/usr/bin/env bash
# Step 2: install the NGINX Ingress Controller - the "front door" that
# receives all web traffic on ports 80/443 and forwards it to the services.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common.sh"

ensure_root "$@"
load_env
compute_hosts

export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
command_exists kubectl || die "kubectl not found. Run 10-install-k3s.sh first."

log "Installing NGINX Ingress Controller"
kubectl apply -f "${INGRESS_NGINX_MANIFEST_URL}"

wait_for_deployment ingress-nginx ingress-nginx-controller 600s
wait_for_load_balancer_ip ingress-nginx ingress-nginx-controller 300

# At 1M requests a day the access log alone is ~1M lines a day; k3s would
# rotate it away within minutes anyway (doc/SIZING-FOR-1M-REQUESTS-A-DAY.md,
# section 4). Error logs stay on. To debug a routing problem temporarily:
#   kubectl -n ingress-nginx patch configmap ingress-nginx-controller --type merge -p '{"data":{"disable-access-log":"false"}}'
log "Switching the ingress access log off (error log stays on)"
kubectl -n ingress-nginx patch configmap ingress-nginx-controller --type merge \
  -p '{"data":{"disable-access-log":"true"}}' >/dev/null

log "NGINX Ingress Controller installation finished"
