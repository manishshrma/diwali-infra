#!/usr/bin/env bash
# Step 15: weekly log cleanup so the disk never fills up.
#
# Where the logs are:
#   /var/log/moment-forever/<service>/   the services' own log files
#                                         (each Deployment mounts this folder at /app/logs)
#   journalctl -u k3s                     k3s itself
#   kubectl logs ...                      container output (rotated by k3s at 10 MB x 3)
#
# What this installs:
#   - a systemd timer that runs every Sunday at 03:00 and deletes service log
#     files older than LOG_RETENTION_DAYS (default 7), trims the system
#     journal, and removes unused container images
#   - a journald size cap, so k3s/system logs stay under 300 MB
# Safe to run twice.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common.sh"

ensure_root "$@"
load_env

LOG_ROOT=/var/log/moment-forever
CLEANUP_SCRIPT=/usr/local/sbin/moment-forever-log-cleanup.sh

log "Creating ${LOG_ROOT}/<service> folders (the Deployments mount them at /app/logs)"
for svc in gateway platform booking payment billing; do
  mkdir -p "${LOG_ROOT}/${svc}"
done
chmod 755 "${LOG_ROOT}"

log "Installing ${CLEANUP_SCRIPT} (retention: ${LOG_RETENTION_DAYS} days)"
cat > "${CLEANUP_SCRIPT}" <<EOF
#!/usr/bin/env bash
# Weekly cleanup installed by bootstrap/k3s/15-setup-log-cleanup.sh.
# Run by hand any time with: sudo ${CLEANUP_SCRIPT}
set -u
RETENTION_DAYS=${LOG_RETENTION_DAYS}
echo "[moment-forever-log-cleanup] start \$(date '+%F %T'); disk before: \$(df -h / | awk 'NR==2 {print \$5 " used"}')"

# 1. Service log files older than RETENTION_DAYS. Files still being written
#    are modified every minute, so they are never matched.
deleted=\$(find ${LOG_ROOT} -type f -mtime +\${RETENTION_DAYS} -print -delete | wc -l)
echo "[moment-forever-log-cleanup] deleted \${deleted} service log file(s) older than \${RETENTION_DAYS} days"

# 2. System journal (k3s, sshd, ...) - keep RETENTION_DAYS and at most 300 MB.
journalctl --vacuum-time="\${RETENTION_DAYS}d" --vacuum-size=300M >/dev/null 2>&1 || true

# 3. Container images that no running pod uses (old builds).
if command -v k3s >/dev/null 2>&1; then
  k3s crictl rmi --prune >/dev/null 2>&1 || true
fi

echo "[moment-forever-log-cleanup] done; disk after: \$(df -h / | awk 'NR==2 {print \$5 " used"}')"
EOF
chmod 755 "${CLEANUP_SCRIPT}"

log "Installing the systemd service + weekly timer"
cat > /etc/systemd/system/moment-forever-log-cleanup.service <<'EOF'
[Unit]
Description=Moment Forever weekly log cleanup

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/moment-forever-log-cleanup.sh
EOF

cat > /etc/systemd/system/moment-forever-log-cleanup.timer <<'EOF'
[Unit]
Description=Run the Moment Forever log cleanup every week

[Timer]
# Every Sunday at 03:00 server time. Persistent=true runs a missed one at next boot.
OnCalendar=Sun *-*-* 03:00:00
Persistent=true
RandomizedDelaySec=15min

[Install]
WantedBy=timers.target
EOF

log "Capping the system journal (300 MB, ${LOG_RETENTION_DAYS} days)"
mkdir -p /etc/systemd/journald.conf.d
cat > /etc/systemd/journald.conf.d/moment-forever.conf <<EOF
[Journal]
SystemMaxUse=300M
MaxRetentionSec=${LOG_RETENTION_DAYS}day
EOF
systemctl restart systemd-journald || true

systemctl daemon-reload
systemctl enable --now moment-forever-log-cleanup.timer >/dev/null

log "Log cleanup installed. Next runs:"
systemctl list-timers moment-forever-log-cleanup.timer --no-pager | sed -n '1,2p'
log "Run it by hand with: sudo ${CLEANUP_SCRIPT}   |   see past runs with: journalctl -u moment-forever-log-cleanup"
