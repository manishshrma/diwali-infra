# Bootstrap: from a fresh Ubuntu server to a running Moment Forever

These scripts turn **any** Ubuntu 22.04/24.04 server with a public IP into the
complete dev environment. They never call a cloud API, so they are the same on
Oracle Cloud, AWS, Google, Azure or Hetzner (decision D2 in
[doc/CLOUD-MOVE-DECISIONS.md](../../doc/CLOUD-MOVE-DECISIONS.md)).

The full, plain-English walkthrough (creating the server, DNS, every `.env`
value, checks, troubleshooting) is
[doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md](../../doc/DEPLOYMENT-GUIDE-ANY-CLOUD.md).
This file is the short version for people who have done it before.

- **OS:** Ubuntu 22.04 or 24.04 LTS, Intel or ARM (our images are built for both)
- **Kubernetes:** single-node k3s
- **Ingress:** NGINX Ingress Controller + cert-manager (Let's Encrypt)
- **GitOps:** Argo CD + Argo CD Image Updater
- **Hostnames:** `api.dev.decevent.com`, `argocd.dev.decevent.com`, `dashboard.dev.decevent.com`

## What each script does

| Script | What it does |
|---|---|
| `00-prepare-host.sh` | Checks Ubuntu version, memory, disk, CPU type; installs `curl`, `git`, `jq`. |
| `05-open-host-firewall.sh` | Removes the blanket REJECT rules that Oracle's Ubuntu images ship with, so ports 80/443 and pod-to-node traffic work. No-op on other clouds. |
| `10-install-k3s.sh` | Installs k3s (Traefik off, container log rotation on). |
| `15-setup-log-cleanup.sh` | Creates `/var/log/moment-forever/<service>` and a weekly timer that deletes log files older than `LOG_RETENTION_DAYS`, trims the journal and prunes unused images. |
| `20-install-nginx-ingress.sh` | Installs the NGINX ingress controller (the web front door); access log off. |
| `25-install-cert-manager.sh` | Installs cert-manager and the Let's Encrypt issuers (free HTTPS, auto-renewed). |
| `30-install-argocd.sh` | Installs Argo CD. |
| `40-configure-argocd-repo-access.sh` | Gives Argo CD the GitHub token for this repo. |
| `50-install-image-updater.sh` | Installs Image Updater and gives it the Docker Hub token. |
| `55-create-app-secrets.sh` | Creates the Kubernetes Secrets (database password, JWT, Razorpay, SMTP, ...) from `.env`. Nothing secret is in Git. |
| `60-bootstrap-moment-forever.sh` | Checks DNS, that this checkout matches GitHub, and that the hostnames in `.env` match the manifests; then creates the Argo CD root application. Argo CD deploys everything else. |

Every script is safe to run twice.

## Run it

```bash
# on the server, after: git clone <this repo>
cd moment-forever-infra/bootstrap/k3s
cp env.example .env
nano .env                 # fill in every value; env.example explains each one
chmod +x ./*.sh
./bootstrap-all.sh        # or run the scripts one by one, in order
```

Before running, the **cloud** firewall must allow TCP 22, 80 and 443, and the
three hostnames must have DNS `A` records pointing at the server's public IP.

## After it finishes

```bash
kubectl get applications -n argocd          # all Synced / Healthy after ~15 minutes
kubectl get pods -n moment-forever-dev      # all Running
kubectl get certificate -A                  # all READY True
```

- API: `https://api.dev.decevent.com/api/platform/actuator/health`
- Argo CD: `https://argocd.dev.decevent.com` (user `admin`, password:
  `kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d; echo`)
- Kubernetes Dashboard: `https://dashboard.dev.decevent.com`, token:
  `kubectl -n kubernetes-dashboard create token viewer` (view-only; see
  `clusters/dev/dashboard/README.md` for the full-admin option)

## Changing a secret later

Edit `.env`, run `./55-create-app-secrets.sh`, then restart the service:
`kubectl rollout restart deploy/<service> -n moment-forever-dev`.

## Where the logs are

- `kubectl logs -n moment-forever-dev deploy/<service>` (what the service prints)
- `/var/log/moment-forever/<service>/` on the server (the service's own log files;
  cleaned weekly by the timer from step 15: `systemctl list-timers moment-forever-log-cleanup.timer`)
