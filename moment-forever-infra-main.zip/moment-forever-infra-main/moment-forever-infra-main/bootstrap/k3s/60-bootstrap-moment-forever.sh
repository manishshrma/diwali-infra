#!/usr/bin/env bash
# Step 6: hand the cluster to Argo CD. From here on Argo CD reads this Git
# repository and keeps the server matching it; nobody deploys by hand.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common.sh"

ensure_root "$@"
load_env
compute_hosts
check_dns

export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

ensure_repo_branch_synced
validate_manifest_inputs

for secret in postgres-secret gateway-secret platform-secret booking-secret payment-secret billing-secret; do
  kubectl get secret "$secret" -n "${APP_NAMESPACE}" >/dev/null 2>&1 \
    || die "Secret ${APP_NAMESPACE}/${secret} is missing. Run 55-create-app-secrets.sh first."
done

log "Applying Argo CD AppProject and root application from local checkout"
kubectl apply -f "$REPO_ROOT/argocd/app-project.yaml"
kubectl apply -f "$REPO_ROOT/argocd/root-application.yaml"

log "Waiting for root application to exist"
for _ in $(seq 1 60); do
  if kubectl get application moment-forever-root -n argocd >/dev/null 2>&1; then
    break
  fi
  sleep 5
done
kubectl get application moment-forever-root -n argocd >/dev/null 2>&1 || die "Argo CD root application was not created"

log "Waiting for child applications to appear"
for app_name in \
  ingress \
  argocd-ui \
  dashboard \
  moment-forever-shared-infra-dev \
  moment-forever-platform-db-dev \
  moment-forever-booking-db-dev \
  moment-forever-payment-db-dev \
  moment-forever-platform-dev \
  moment-forever-booking-dev \
  moment-forever-payment-dev \
  moment-forever-billing-dev \
  moment-forever-gateway-dev
do
  for _ in $(seq 1 60); do
    if kubectl get application "$app_name" -n argocd >/dev/null 2>&1; then
      break
    fi
    sleep 5
  done
  kubectl get application "$app_name" -n argocd >/dev/null 2>&1 || die "Expected child application '$app_name' was not created"
done

log "Bootstrap finished. Argo CD is now managing Moment Forever from Git."
log "The first start takes 10-15 minutes (image downloads + Java warm-up)."
log ""
log "  API:        https://${APP_HOST}/api/platform/actuator/health"
log "  Argo CD:    https://${ARGOCD_HOST}   (user admin; password: kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d; echo)"
log "  Dashboard:  https://${DASHBOARD_HOST}  (view-only token: kubectl -n kubernetes-dashboard create token viewer)"
log ""
log "Watch progress with:  kubectl get applications -n argocd   and   kubectl get pods -n ${APP_NAMESPACE} -w"
log "Certificates:         kubectl get certificate -A   (READY must become True; needs DNS + port 80 reachable)"
