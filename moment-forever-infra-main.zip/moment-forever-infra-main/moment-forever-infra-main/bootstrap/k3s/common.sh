#!/usr/bin/env bash
# Shared helpers for every bootstrap script in this folder.
# Nothing in here talks to a cloud API: the scripts work on any Ubuntu server
# that has a public IP (decision D2 in doc/CLOUD-MOVE-DECISIONS.md).
set -Eeuo pipefail

BOOTSTRAP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$BOOTSTRAP_DIR/../.." && pwd)"
ENV_FILE="${BOOTSTRAP_ENV_FILE:-$BOOTSTRAP_DIR/.env}"

# Namespace where the Moment Forever services run. Must match the manifests
# under clusters/dev/ and argocd/applications/.
APP_NAMESPACE="moment-forever-dev"

log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

warn() {
  printf '[%s] WARNING: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2
}

die() {
  printf '[%s] ERROR: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2
  exit 1
}

ensure_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    log "Re-running $0 with sudo"
    exec sudo -E bash "$0" "$@"
  fi
}

load_env() {
  if [[ -f "$ENV_FILE" ]]; then
    set -a
    # shellcheck disable=SC1090
    source "$ENV_FILE"
    set +a
  else
    warn "No $ENV_FILE found. Copy env.example to .env and fill it in."
  fi

  : "${INFRA_REPO_URL:=https://github.com/ForeverMoment-Corp/moment-forever-infra.git}"
  : "${INFRA_REPO_BRANCH:=main}"
  : "${K3S_CHANNEL:=stable}"
  : "${INGRESS_NGINX_MANIFEST_URL:=https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.12.3/deploy/static/provider/cloud/deploy.yaml}"
  : "${ARGOCD_INSTALL_URL:=https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml}"
  : "${ARGOCD_IMAGE_UPDATER_INSTALL_URL:=https://raw.githubusercontent.com/argoproj-labs/argocd-image-updater/stable/config/install.yaml}"
  : "${CERT_MANAGER_INSTALL_URL:=https://github.com/cert-manager/cert-manager/releases/download/v1.21.2/cert-manager.yaml}"
  : "${PUBLIC_IP:=}"
  : "${APP_HOST:=}"
  : "${ARGOCD_HOST:=}"
  : "${DASHBOARD_HOST:=}"
  : "${LOG_RETENTION_DAYS:=7}"
}

require_env() {
  local var_name
  for var_name in "$@"; do
    if [[ -z "${!var_name:-}" ]]; then
      die "Required variable '$var_name' is missing. Fill it in $ENV_FILE first (see env.example for what it means)."
    fi
  done
}

# Ubuntu LTS versions this bootstrap has been validated against.
SUPPORTED_UBUNTU_VERSIONS=("22.04" "24.04")

require_ubuntu() {
  if [[ ! -f /etc/os-release ]]; then
    die "/etc/os-release not found. This bootstrap targets Ubuntu LTS (${SUPPORTED_UBUNTU_VERSIONS[*]})."
  fi

  # shellcheck disable=SC1091
  source /etc/os-release

  local version
  for version in "${SUPPORTED_UBUNTU_VERSIONS[@]}"; do
    if [[ "${ID:-}" == "ubuntu" && "${VERSION_ID:-}" == "$version" ]]; then
      return 0
    fi
  done

  die "Unsupported OS '${PRETTY_NAME:-unknown}'. Use Ubuntu ${SUPPORTED_UBUNTU_VERSIONS[*]} LTS for this bootstrap."
}

# The server's public IP and the three hostnames come from .env. We do not
# guess them from cloud metadata any more, because every cloud does that
# differently and a wrong guess silently breaks HTTPS certificates.
compute_hosts() {
  require_env PUBLIC_IP APP_HOST ARGOCD_HOST DASHBOARD_HOST
  if [[ ! "$PUBLIC_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    die "PUBLIC_IP='$PUBLIC_IP' does not look like an IPv4 address."
  fi
}

# Warn (do not stop) when a hostname does not resolve to PUBLIC_IP yet.
# cert-manager cannot issue a certificate until DNS is right.
check_dns() {
  local host resolved
  for host in "$APP_HOST" "$ARGOCD_HOST" "$DASHBOARD_HOST"; do
    resolved="$(getent ahostsv4 "$host" 2>/dev/null | awk '{print $1}' | head -n1 || true)"
    if [[ "$resolved" != "$PUBLIC_IP" ]]; then
      warn "DNS: '$host' resolves to '${resolved:-nothing}', expected '$PUBLIC_IP'. Add/fix the A record at your DNS provider; HTTPS certificates will fail until it is right."
    fi
  done
}

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

wait_for_deployment() {
  local namespace="$1"
  local name="$2"
  local timeout="${3:-600s}"
  kubectl rollout status "deployment/${name}" -n "$namespace" --timeout="$timeout"
}

wait_for_statefulset() {
  local namespace="$1"
  local name="$2"
  local timeout="${3:-600s}"
  kubectl rollout status "statefulset/${name}" -n "$namespace" --timeout="$timeout"
}

wait_for_load_balancer_ip() {
  local namespace="$1"
  local service="$2"
  local timeout_seconds="${3:-300}"
  local deadline current
  deadline=$((SECONDS + timeout_seconds))

  while (( SECONDS < deadline )); do
    current="$(kubectl get svc "$service" -n "$namespace" -o jsonpath='{.status.loadBalancer.ingress[0].ip}{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || true)"
    if [[ -n "$current" ]]; then
      log "Service ${namespace}/${service} is exposed via: $current"
      return 0
    fi
    sleep 5
  done

  warn "Timed out waiting for an external address on ${namespace}/${service}. On a single k3s node this is usually harmless; continue and test from the public IP."
}

configure_kubeconfig_for_login_user() {
  local login_user login_home
  login_user="${SUDO_USER:-ubuntu}"
  if ! getent passwd "$login_user" >/dev/null 2>&1; then
    warn "User '$login_user' does not exist; skipping kubeconfig copy."
    return
  fi

  login_home="$(getent passwd "$login_user" | cut -d: -f6)"
  mkdir -p "$login_home/.kube"
  cp /etc/rancher/k3s/k3s.yaml "$login_home/.kube/config"
  chown -R "$login_user:$login_user" "$login_home/.kube"
  chmod 600 "$login_home/.kube/config"
}

warn_if_low_resources() {
  local total_mem_mb available_disk_gb arch
  total_mem_mb="$(free -m | awk '/^Mem:/ {print $2}')"
  available_disk_gb="$(df -BG / | awk 'NR==2 {gsub("G","",$4); print $4}')"
  arch="$(uname -m)"

  log "Server: ${arch}, ${total_mem_mb} MB RAM, ${available_disk_gb} GB free disk"

  if [[ "${total_mem_mb}" -lt 14000 ]]; then
    warn "This server has ${total_mem_mb} MB RAM. The full stack needs about 13.5 GB (doc/SIZING-FOR-1M-REQUESTS-A-DAY.md). It will install, but services may be OOM-killed."
  fi

  if [[ "${available_disk_gb}" -lt 30 ]]; then
    warn "Only ${available_disk_gb} GB disk is free. Images, logs and databases may exhaust it; 100 GB is recommended."
  fi

  if [[ "$arch" == "aarch64" || "$arch" == "arm64" ]]; then
    log "ARM server detected: every image must be built for arm64 as well (decision D5; the shared CI workflow does this)."
  fi
}

# git refuses to read a checkout owned by another user (the repo is cloned
# by 'ubuntu' but the scripts run as root), so pass safe.directory explicitly.
repo_git() {
  git -c safe.directory="$REPO_ROOT" -C "$REPO_ROOT" "$@"
}

# Argo CD reads GitHub, not this checkout. Stop if the two differ, otherwise
# the operator thinks a change is deployed when it is not even pushed.
ensure_repo_branch_synced() {
  local local_head remote_head fetch_url
  fetch_url="$INFRA_REPO_URL"
  # For a private repository, fetch with the PAT so the check works non-interactively.
  if [[ -n "${GITHUB_USERNAME:-}" && -n "${GITHUB_TOKEN:-}" && "$fetch_url" == https://github.com/* ]]; then
    fetch_url="https://${GITHUB_USERNAME}:${GITHUB_TOKEN}@${fetch_url#https://}"
  fi
  repo_git fetch --quiet "$fetch_url" "$INFRA_REPO_BRANCH" \
    || die "Could not fetch ${INFRA_REPO_URL} (branch ${INFRA_REPO_BRANCH}). Check INFRA_REPO_URL, the branch name and GITHUB_TOKEN."
  local_head="$(repo_git rev-parse HEAD)"
  remote_head="$(repo_git rev-parse FETCH_HEAD)"
  if [[ "$local_head" != "$remote_head" ]]; then
    die "This checkout (${local_head:0:8}) is not the same as ${INFRA_REPO_BRANCH} on GitHub (${remote_head:0:8}). Commit and push (or git pull) before bootstrapping Argo CD."
  fi
}

# The hostnames are committed in the manifests; .env must agree with them.
validate_manifest_inputs() {
  local manifest
  grep -q -- "- \"${INFRA_REPO_URL}\"" "$REPO_ROOT/argocd/app-project.yaml" \
    || die "argocd/app-project.yaml sourceRepos does not include ${INFRA_REPO_URL}"
  for manifest in "$REPO_ROOT/argocd/root-application.yaml" "$REPO_ROOT"/argocd/applications/*.yaml; do
    grep -q -- "${INFRA_REPO_URL}" "$manifest" \
      || die "${manifest#$REPO_ROOT/} does not point to ${INFRA_REPO_URL}"
    grep -q "targetRevision: ${INFRA_REPO_BRANCH}" "$manifest" \
      || die "${manifest#$REPO_ROOT/} targetRevision is not ${INFRA_REPO_BRANCH}"
  done
  grep -q "host: ${APP_HOST}" "$REPO_ROOT/clusters/dev/ingress/ingress.yaml" \
    || die "clusters/dev/ingress/ingress.yaml is not configured for ${APP_HOST}. Edit the file (host + tls hosts), push, then rerun."
  grep -q "host: ${ARGOCD_HOST}" "$REPO_ROOT/clusters/dev/argocd/ingress.yaml" \
    || die "clusters/dev/argocd/ingress.yaml is not configured for ${ARGOCD_HOST}. Edit the file, push, then rerun."
  grep -q "host: ${DASHBOARD_HOST}" "$REPO_ROOT/clusters/dev/dashboard/ingress.yaml" \
    || die "clusters/dev/dashboard/ingress.yaml is not configured for ${DASHBOARD_HOST}. Edit the file, push, then rerun."
}
