#!/usr/bin/env bash
# Step 55: turn the secret values in .env into Kubernetes Secrets.
#
# No password or API key lives in Git (decision D12). The Deployments under
# clusters/dev/<service>/ read these Secrets with envFrom/secretKeyRef.
# Argo CD does not manage them, so it never deletes or overwrites them.
#
# Rotating a value = edit .env, rerun this script, restart the service:
#   kubectl rollout restart deploy/<service> -n moment-forever-dev
# Safe to run twice (apply = create or update).
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common.sh"

ensure_root "$@"
load_env

export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
command_exists kubectl || die "kubectl not found. Run 10-install-k3s.sh first."

# Without these the services cannot start at all.
require_env POSTGRES_PASSWORD JWT_SECRET SUPER_ADMIN_EMAIL SUPER_ADMIN_PASSWORD BILLING_INTERNAL_TOKEN

if [[ ${#JWT_SECRET} -lt 32 ]]; then
  die "JWT_SECRET must be at least 32 characters (generate one with: openssl rand -base64 32)."
fi
if [[ ${#SUPER_ADMIN_PASSWORD} -lt 8 ]]; then
  die "SUPER_ADMIN_PASSWORD must be at least 8 characters."
fi

# Empty optional values only switch a feature off; say so, do not stop.
warn_if_empty() {
  local var_name="$1" what="$2"
  if [[ -z "${!var_name:-}" ]]; then
    warn "$var_name is empty: $what"
  fi
}
warn_if_empty GOOGLE_OIDC_CLIENT_SECRET "Google sign-in will not work."
warn_if_empty PHONE_OTP_SECRET "SMS login codes will be hashed with JWT_SECRET instead (works, but set it)."
warn_if_empty SMTP_USERNAME "booking emails will not be sent."
warn_if_empty SMTP_PASSWORD "booking emails will not be sent."
warn_if_empty RAZORPAY_KEY_ID "payments will not work."
warn_if_empty RAZORPAY_KEY_SECRET "payments will not work."
warn_if_empty RAZORPAY_WEBHOOK_SECRET "Razorpay webhooks will be rejected."
if [[ "${PHONE_SMS_PROVIDER:-none}" == "none" ]]; then
  warn "PHONE_SMS_PROVIDER=none: phone login is switched off."
fi

log "Making sure namespace ${APP_NAMESPACE} exists"
kubectl create namespace "${APP_NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f - >/dev/null

# create_secret <name> KEY=VALUE ...   (apply = create or update)
create_secret() {
  local name="$1"; shift
  local args=()
  local pair
  for pair in "$@"; do
    args+=("--from-literal=${pair}")
  done
  kubectl create secret generic "$name" \
    --namespace "${APP_NAMESPACE}" \
    "${args[@]}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  log "Secret ${APP_NAMESPACE}/${name} written"
}

# Shared by the three PostgreSQL StatefulSets (secretKeyRef).
create_secret postgres-secret \
  "POSTGRES_PASSWORD=${POSTGRES_PASSWORD}"

create_secret gateway-secret \
  "JWT_SECRET=${JWT_SECRET}"

create_secret platform-secret \
  "SPRING_DATASOURCE_USERNAME=postgres" \
  "SPRING_DATASOURCE_PASSWORD=${POSTGRES_PASSWORD}" \
  "JWT_SECRET=${JWT_SECRET}" \
  "SUPER_ADMIN_EMAIL=${SUPER_ADMIN_EMAIL}" \
  "SUPER_ADMIN_PASSWORD=${SUPER_ADMIN_PASSWORD}" \
  "GOOGLE_OIDC_CLIENT_SECRET=${GOOGLE_OIDC_CLIENT_SECRET:-}" \
  "PHONE_OTP_SECRET=${PHONE_OTP_SECRET:-}" \
  "PHONE_SMS_PROVIDER=${PHONE_SMS_PROVIDER:-none}" \
  "TWOFACTOR_API_KEY=${TWOFACTOR_API_KEY:-}" \
  "TWOFACTOR_OTP_TEMPLATE=${TWOFACTOR_OTP_TEMPLATE:-}" \
  "MSG91_AUTH_KEY=${MSG91_AUTH_KEY:-}" \
  "MSG91_OTP_TEMPLATE_ID=${MSG91_OTP_TEMPLATE_ID:-}" \
  "EXOTEL_API_KEY=${EXOTEL_API_KEY:-}" \
  "EXOTEL_API_TOKEN=${EXOTEL_API_TOKEN:-}" \
  "EXOTEL_SID=${EXOTEL_SID:-}" \
  "EXOTEL_SUBDOMAIN=${EXOTEL_SUBDOMAIN:-api.exotel.com}" \
  "EXOTEL_SENDER_ID=${EXOTEL_SENDER_ID:-}" \
  "EXOTEL_DLT_ENTITY_ID=${EXOTEL_DLT_ENTITY_ID:-}" \
  "EXOTEL_DLT_TEMPLATE_ID=${EXOTEL_DLT_TEMPLATE_ID:-}"

create_secret booking-secret \
  "SPRING_DATASOURCE_USERNAME=postgres" \
  "SPRING_DATASOURCE_PASSWORD=${POSTGRES_PASSWORD}" \
  "SMTP_USERNAME=${SMTP_USERNAME:-}" \
  "SMTP_PASSWORD=${SMTP_PASSWORD:-}" \
  "MAIL_FROM_ADDRESS=${MAIL_FROM_ADDRESS:-bookings@decevent.com}" \
  "BILLING_INTERNAL_TOKEN=${BILLING_INTERNAL_TOKEN}" \
  "BOOKING_SMS_NOTIFICATIONS_ENABLED=${BOOKING_SMS_NOTIFICATIONS_ENABLED:-false}" \
  "BOOKING_SMS_PROVIDER=${BOOKING_SMS_PROVIDER:-log}" \
  "BOOKING_SMS_CONFIRMED_TEMPLATE=${BOOKING_SMS_CONFIRMED_TEMPLATE:-}" \
  "BOOKING_SMS_CANCELLED_TEMPLATE=${BOOKING_SMS_CANCELLED_TEMPLATE:-}" \
  "TWOFACTOR_API_KEY=${TWOFACTOR_API_KEY:-}" \
  "TWOFACTOR_SENDER_ID=${TWOFACTOR_SENDER_ID:-}" \
  "MSG91_AUTH_KEY=${MSG91_AUTH_KEY:-}" \
  "EXOTEL_API_KEY=${EXOTEL_API_KEY:-}" \
  "EXOTEL_API_TOKEN=${EXOTEL_API_TOKEN:-}" \
  "EXOTEL_SID=${EXOTEL_SID:-}" \
  "EXOTEL_SUBDOMAIN=${EXOTEL_SUBDOMAIN:-api.exotel.com}" \
  "EXOTEL_SENDER_ID=${EXOTEL_SENDER_ID:-}" \
  "EXOTEL_DLT_ENTITY_ID=${EXOTEL_DLT_ENTITY_ID:-}" \
  "BOOKING_WHATSAPP_NOTIFICATIONS_ENABLED=${BOOKING_WHATSAPP_NOTIFICATIONS_ENABLED:-false}" \
  "WHATSAPP_API_ENDPOINT=${WHATSAPP_API_ENDPOINT:-}" \
  "WHATSAPP_API_TOKEN=${WHATSAPP_API_TOKEN:-}"

create_secret payment-secret \
  "SPRING_DATASOURCE_USERNAME=postgres" \
  "SPRING_DATASOURCE_PASSWORD=${POSTGRES_PASSWORD}" \
  "RAZORPAY_KEY_ID=${RAZORPAY_KEY_ID:-}" \
  "RAZORPAY_KEY_SECRET=${RAZORPAY_KEY_SECRET:-}" \
  "RAZORPAY_WEBHOOK_SECRET=${RAZORPAY_WEBHOOK_SECRET:-}" \
  "SLACK_WEBHOOK_URL=${SLACK_WEBHOOK_URL:-}"

create_secret billing-secret \
  "BILLING_INTERNAL_TOKEN=${BILLING_INTERNAL_TOKEN}"

log "All application secrets written to namespace ${APP_NAMESPACE}."
log "If a service is already running and you changed a value, restart it: kubectl rollout restart deploy/<service> -n ${APP_NAMESPACE}"
