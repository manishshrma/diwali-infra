# Kubernetes Dashboard

A web page at `https://dashboard.dev.decevent.com` to see what is running:
deployments, pods, restarts, events, logs, CPU and memory.

| File | What it is |
|---|---|
| `recommended.yaml` | The Dashboard itself (upstream manifest, unchanged). |
| `viewer.yaml` | The **view-only** login account used every day (decision D11). |
| `ingress.yaml` | The public address + HTTPS certificate. |
| `kustomization.yaml` | Lists the files above and adds memory limits. |
| `optional-admin-user.yaml` | **Not deployed.** Full-admin account for a one-off task, applied by hand and deleted afterwards. |

## Log in (view-only)

On the server:

```bash
kubectl -n kubernetes-dashboard create token viewer
```

Open the Dashboard, choose **Token**, paste it. The token is valid for one
hour; run the command again for a new one. Change the namespace drop-down
(top left) to `moment-forever-dev` to see our services.

This login can look at everything but cannot change anything, so a leaked
token cannot do damage. It cannot read Secrets either.

## Full admin (rare)

```bash
kubectl apply -f clusters/dev/dashboard/optional-admin-user.yaml
kubectl -n kubernetes-dashboard create token admin-user --duration=30m
# ... do the task ...
kubectl delete -f clusters/dev/dashboard/optional-admin-user.yaml   # token stops working at once
```

Everything a full-admin token can do in the Dashboard can also be done with
`kubectl` on the server, which is not reachable from the internet. Prefer that.
